"""
Generator Fișe de Monitorizare Lunară — CIAPAD Casa Olandeză
Citește din Master Excel (BENEFICIARI + EVALUARE_FUNCTIONALA)
Generează un singur .docx cu toate fișele, fiecare pe pagină impară
Conform Ordinului 82/2019 actualizat prin Ordinul 3222/2024
"""

from docx import Document
from docx.shared import Cm, Pt, Mm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl import load_workbook
import datetime
from pathlib import Path
import sys

# ── Configurare ──
EXCEL  = "Master_CORE_v2_CORECTAT.xlsx"
OUTPUT = None  # calculat dinamic

LUNI_RO = ["","Ianuarie","Februarie","Martie","Aprilie","Mai","Iunie",
           "Iulie","August","Septembrie","Octombrie","Noiembrie","Decembrie"]

CENTRU     = "CIAPAD Casa Olandeză"
ORGANIZATIE = "De WesterCirkel România"
ORAS       = "Giurgiu"

# Echipa multidisciplinară — se poate actualiza
ECHIPA = {
    "manager_caz":      "Preda Elena",
    "asistent_social":  "Pirlog Ionela",
    "psiholog":         "Bodeanu Nicoleta Adina",
    "asistent_medical": "Ilina Florina",
}

# ── Helpers Excel ──
def norm_key(s):
    import unicodedata, re
    s = str(s).strip().lower()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r'\s+', ' ', s)

def get_headers(ws):
    headers = {}
    row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
    for idx, v in enumerate(row):
        if v is not None:
            headers[norm_key(v)] = idx
    return headers

def find_col(headers, *needles):
    for n in needles:
        nk = norm_key(n)
        if nk in headers:
            return headers[nk]
    for k, idx in headers.items():
        for n in needles:
            if norm_key(n) in k:
                return idx
    return None

def get_sheet(wb, *names):
    lower = {s.lower(): s for s in wb.sheetnames}
    for n in names:
        if n.lower() in lower:
            return wb[lower[n.lower()]]
    return None

def resolve_excel(name):
    script_dir = Path(__file__).resolve().parent
    p = script_dir / name
    if p.exists():
        return p
    candidates = sorted(script_dir.glob("*.xlsx"))
    if candidates:
        print(f"Notă: nu găsesc '{name}'. Folosesc: {candidates[0].name}")
        return candidates[0]
    name = input("Introdu numele fișierului Excel: ").strip()
    return script_dir / name

def fmt_date(v):
    if isinstance(v, (datetime.datetime, datetime.date)):
        d = v if isinstance(v, datetime.date) else v.date()
        return d.strftime("%d.%m.%Y")
    if v is None:
        return ""
    s = str(v).strip()
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.datetime.strptime(s, fmt).strftime("%d.%m.%Y")
        except:
            pass
    return s

# ── Citire date ──
def load_beneficiari(wb):
    ws = get_sheet(wb, "BENEFICIARI")
    if ws is None:
        raise RuntimeError("Nu găsesc foaia BENEFICIARI.")
    h = get_headers(ws)
    out = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or all(v is None or str(v).strip() == "" for v in row):
            continue
        status = row[find_col(h, "status")] if find_col(h, "status") is not None else None
        if str(status).strip().upper() != "ACTIV":
            continue
        bid   = str(row[find_col(h, "id_beneficiar")] or "").strip()
        nume  = str(row[find_col(h, "nume")] or "").strip()
        pren  = str(row[find_col(h, "prenume")] or "").strip()
        diag1 = str(row[find_col(h, "diagnostic_principal")] or "").strip()
        diag2 = str(row[find_col(h, "diagnostic_secundar")] or "").strip()
        grad  = str(row[find_col(h, "grad_handicap")] or "").strip()
        sosire = row[find_col(h, "data_sosirii_centru", "data sosirii")]
        obs_med = str(row[find_col(h, "observatii_medicale")] or "").strip()
        diag = " / ".join([d for d in [diag1, diag2] if d])
        out.append({
            "id": bid,
            "nume_complet": f"{nume} {pren}".strip(),
            "nume": nume,
            "prenume": pren,
            "diag": diag,
            "grad": grad,
            "sosire": fmt_date(sosire),
            "obs_med": obs_med,
        })
    return out

def load_evaluare(wb):
    ws = get_sheet(wb, "EVALUARE_FUNCTIONALA")
    if ws is None:
        return {}
    h = get_headers(ws)
    out = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row:
            continue
        bid = str(row[find_col(h, "id_beneficiar")] or "").strip()
        if not bid:
            continue
        def val(col, *names):
            c = find_col(h, col, *names)
            if c is None or c >= len(row):
                return ""
            v = row[c]
            return "" if v is None else str(v).strip()
        out[bid] = {
            "mobilitate":   val("mobilitate"),
            "igiena":       val("igiena_personala", "igiena"),
            "hranire":      val("hranire"),
            "comunicare":   val("comunicare_verbala", "comunicare verbala"),
            "cooperare":    val("cooperare"),
            "risc_caderi":  val("risc_caderi", "risc caderi"),
            "risc_crize":   val("risc_crize", "risc crize"),
            "agitatie":     val("agitatie"),
            "supraveghere": val("nivel_supraveghere", "supraveghere"),
        }
    return out

# ── Text helpers ──
def _parse_nivel(s):
    """Extrage cifra de nivel din strings ca '3 mers independent'."""
    if not s:
        return None
    try:
        return int(str(s).strip()[0])
    except:
        return None

def text_risc_evaluare(e):
    """Generează text pentru secțiunea Evaluare risc pe baza profilului."""
    if not e:
        return "Beneficiarul este monitorizat conform protocoalelor centrului."
    risc_caderi = (e.get("risc_caderi") or "").upper()
    risc_crize  = (e.get("risc_crize") or "").upper()
    agitatie    = (e.get("agitatie") or "").upper()
    supr        = _parse_nivel(e.get("supraveghere"))
    mob         = _parse_nivel(e.get("mobilitate"))

    parti = []
    if risc_crize == "DA":
        parti.append("prezintă risc de crize comițiale, personalul fiind instruit cu privire la protocolul de intervenție")
    if risc_caderi == "DA":
        parti.append("prezintă risc de căderi, necesitând supraveghere sporită în timpul deplasării")
    if agitatie == "DA":
        parti.append("poate prezenta episoade de agitație, personalul monitorizând și intervenind conform procedurilor")
    if mob is not None and mob <= 1:
        parti.append("mobilitatea limitată impune asistență permanentă pentru prevenirea incidentelor")

    if not parti:
        if supr is not None and supr <= 1:
            return "Beneficiarul necesită supraveghere permanentă; personalul monitorizează continuu starea acestuia."
        return "Beneficiarul conștientizează un pericol și alertează personalul. Nu au fost identificate riscuri deosebite în această perioadă."

    baza = "Beneficiarul " + ", ".join(parti) + "."
    return baza

def text_deprinderi(e):
    """Text deprinderi de viață independentă bazat pe evaluare."""
    if not e:
        return "Beneficiarul participă la activități de dezvoltare a deprinderilor de viață independentă, conform planului personalizat."
    ig = _parse_nivel(e.get("igiena"))
    hr = _parse_nivel(e.get("hranire"))
    mob = _parse_nivel(e.get("mobilitate"))

    parti = []
    if mob is not None:
        if mob >= 3:
            parti.append("se deplasează independent în spațiile centrului")
        elif mob == 2:
            parti.append("se deplasează cu sprijin minim")
        else:
            parti.append("necesită asistență pentru deplasare")
    if ig is not None:
        if ig >= 3:
            parti.append("realizează activitățile de igienă personală independent")
        elif ig >= 1:
            parti.append("realizează activitățile de igienă personală cu sprijin parțial")
        else:
            parti.append("necesită asistență integrală pentru igienă personală")
    if hr is not None:
        if hr >= 2:
            parti.append("se alimentează independent")
        elif hr == 1:
            parti.append("este asistat la servirea meselor")
        else:
            parti.append("necesită sprijin integral la alimentație")

    if not parti:
        return "Beneficiarul participă la activități de menținere a deprinderilor de viață independentă, conform planului personalizat."
    return "Beneficiarul " + ", ".join(parti) + ". Activitățile vizează menținerea și dezvoltarea autonomiei personale."

# ── DOCX helpers ──
def add_odd_page_section(doc):
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    sectPr = section._sectPr
    type_el = sectPr.find(qn("w:type"))
    if type_el is None:
        type_el = OxmlElement("w:type")
        sectPr.insert(0, type_el)
    type_el.set(qn("w:val"), "oddPage")
    return section

def set_para_spacing(p, before=0, after=4, line=None):
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after  = Pt(after)
    if line:
        from docx.shared import Pt as _Pt
        pf.line_spacing = _Pt(line)

def add_run(p, text, bold=False, size=10, italic=False, color=None):
    run = p.add_run(text)
    run.bold   = bold
    run.italic = italic
    run.font.size = Pt(size)
    run.font.name = "Times New Roman"
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    return run

def linie_separator(doc, culoare="1A6B3C"):
    """Linie orizontală subțire verde."""
    p = doc.add_paragraph()
    set_para_spacing(p, before=2, after=2)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "4")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), culoare)
    pBdr.append(bottom)
    pPr.append(pBdr)

def adauga_sectiune(doc, titlu, continut, editabil=True):
    """Adaugă o secțiune cu titlu bold și conținut editabil."""
    p = doc.add_paragraph()
    set_para_spacing(p, before=6, after=2)
    add_run(p, f"{titlu}:", bold=True, size=10, color="1A6B3C")
    add_run(p, f"  {continut}", bold=False, size=10)

def adauga_sectiune_goala(doc, titlu, linii=3):
    """Secțiune cu spațiu liber pentru completare manuală — păstrat ca fallback."""
    p = doc.add_paragraph()
    set_para_spacing(p, before=6, after=2)
    add_run(p, f"{titlu}:", bold=True, size=10, color="1A6B3C")
    for _ in range(linii):
        lp = doc.add_paragraph()
        set_para_spacing(lp, before=0, after=0)
        add_run(lp, " " * 80, size=10)
        pPr = lp._p.get_or_add_pPr()
        pBdr = OxmlElement("w:pBdr")
        bottom = OxmlElement("w:bottom")
        bottom.set(qn("w:val"), "single")
        bottom.set(qn("w:sz"), "4")
        bottom.set(qn("w:space"), "1")
        bottom.set(qn("w:color"), "CCCCCC")
        pBdr.append(bottom)
        pPr.append(pBdr)

# ── Texte default inteligente per secțiune ──

def text_demersuri_sociale(benef, e):
    """Secțiunea 2 — Demersuri asistență socială."""
    return ("Nu sunt necesare demersuri de asistență socială în această perioadă. "
            "Beneficiarul este monitorizat în cadrul centrului conform planului personalizat de îngrijire.")

def text_consiliere_psihologica(benef, e):
    """Secțiunea 3 — Evaluare și consiliere psihologică."""
    com  = _parse_nivel(e.get("comunicare"))
    coop = _parse_nivel(e.get("cooperare"))
    agit = (e.get("agitatie") or "").upper()
    nume = benef["prenume"] if benef.get("prenume") else benef["nume_complet"]

    # Participare la activități
    if com is not None and com >= 3:
        participare = (f"{nume} participă activ la activitățile de grup, manifestând interes "
                       "și inițiativă în interacțiunile cu colegii și personalul centrului")
    elif com is not None and com >= 1:
        participare = (f"{nume} participă la activitățile de grup cu sprijin din partea personalului, "
                       "manifestând interes variabil în funcție de context și dispoziție")
    else:
        participare = (f"{nume} participă la activitățile de grup cu asistență permanentă din partea personalului, "
                       "răspunzând la stimuli vizuali și auditivi")

    # Stare emoțională
    if agit == "DA":
        stare = ("Au fost consemnate episoade de agitație pe parcursul lunii; "
                 "personalul a intervenit conform protocolului centrului.")
    elif coop is not None and coop >= 2:
        stare = "Starea emoțională a fost stabilă pe parcursul lunii."
    else:
        stare = ("Starea emoțională a fost variabilă; "
                 "personalul a acordat sprijin pentru menținerea echilibrului emoțional.")

    return f"{participare}. {stare} Consilierea psihologică s-a desfășurat conform planificării."

def text_consiliere_vocationala(benef, e):
    """Secțiunea 4 — Consiliere vocațională."""
    com  = _parse_nivel(e.get("comunicare"))
    mob  = _parse_nivel(e.get("mobilitate"))
    coop = _parse_nivel(e.get("cooperare"))

    if mob is not None and mob >= 2 and com is not None and com >= 2:
        integrare = ("Beneficiarul este inclus în activitățile de grup alături de ceilalți colegi, "
                     "participând la activități recreative, educative și de socializare")
    elif coop is not None and coop <= 1:
        integrare = ("Beneficiarul este inclus în activitățile de grup, deși cooperarea este variabilă; "
                     "personalul încurajează participarea și implicarea acestuia")
    else:
        integrare = ("Beneficiarul participă la activitățile de grup cu sprijin din partea personalului, "
                     "în funcție de nivelul de autonomie și starea din ziua respectivă")

    return (f"{integrare}. "
            "Activitățile vizează dezvoltarea abilităților de interacțiune socială, "
            "prevenirea izolării și menținerea unui climat pozitiv în cadrul centrului.")

def text_activitati(benef, e):
    """Secțiunea 6 — Activități desfășurate."""
    mob = _parse_nivel(e.get("mobilitate"))
    com = _parse_nivel(e.get("comunicare"))

    activitati = ["meloterapie", "ludoterapie"]
    if mob is not None and mob >= 2:
        activitati.append("activități în aer liber și plimbări")
    if com is not None and com >= 2:
        activitati.append("activități educative și de stimulare cognitivă")
    activitati.append("activități recreative de grup")

    return ("În cursul acestei luni, beneficiarul a participat la: "
            f"{', '.join(activitati)}.")

def text_grad_obiective(benef, e):
    """Secțiunea 9 — Gradul de realizare a obiectivelor."""
    coop = _parse_nivel(e.get("cooperare"))
    if coop is not None and coop >= 2:
        return ("Obiectivele stabilite prin Planul Personalizat de Îngrijire au fost realizate "
                "în proporție satisfăcătoare. Beneficiarul a participat la activitățile planificate "
                "cu cooperare adecvată. Se propune continuarea obiectivelor pentru perioada următoare.")
    else:
        return ("Obiectivele stabilite prin Planul Personalizat de Îngrijire au fost parțial realizate. "
                "Cooperarea beneficiarului a fost variabilă pe parcursul lunii. "
                "Se propune revizuirea obiectivelor și adaptarea intervențiilor pentru perioada următoare.")

def text_opinie_beneficiar(benef, e):
    """Secțiunea 10 — Opinia beneficiarului."""
    com = _parse_nivel(e.get("comunicare"))
    if com is not None and com >= 3:
        return ("Beneficiarul și-a exprimat opinia cu privire la serviciile primite, "
                "manifestând satisfacție față de condițiile de viață din centru și activitățile desfășurate.")
    elif com is not None and com >= 1:
        return ("Beneficiarul și-a exprimat nonverbal sau prin comunicare limitată gradul de satisfacție "
                "față de activitățile și condițiile din centru. Personalul a interpretat semnalele "
                "comportamentale conform cunoașterii individuale a beneficiarului.")
    else:
        return ("Datorită limitărilor de comunicare verbală, opinia beneficiarului a fost evaluată "
                "prin observarea reacțiilor comportamentale și nonverbale de către personalul de îngrijire.")

def text_concluzii(benef, e):
    """Secțiunea 11 — Concluzii și obiective."""
    coop = _parse_nivel(e.get("cooperare"))
    com  = _parse_nivel(e.get("comunicare"))
    risc_crize = (e.get("risc_crize") or "").upper()

    obiective = ["menținerea stării de sănătate și a echilibrului emoțional",
                 "menținerea și consolidarea deprinderilor de viață independentă dobândite",
                 "participarea la activitățile de grup și de socializare"]

    if com is not None and com <= 2:
        obiective.append("stimularea comunicării și a interacțiunii sociale")
    if risc_crize == "DA":
        obiective.append("monitorizarea atentă a stării de sănătate conform protocolului medical")

    return ("Concluzii: Beneficiarul a parcurs luna în condiții corespunzătoare, "
            "cu sprijinul echipei multidisciplinare. "
            f"Obiective pentru perioada următoare: {'; '.join(obiective)}.")

# ── Generator fișă per beneficiar ──
def adauga_fisa(doc, benef, eval_data, luna, an, is_first):
    if not is_first:
        add_odd_page_section(doc)

    e = eval_data.get(benef["id"], {})
    luna_str = LUNI_RO[luna]

    # ── Antet ──
    p_org = doc.add_paragraph()
    p_org.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_para_spacing(p_org, before=0, after=0)
    add_run(p_org, ORGANIZATIE, bold=True, size=12, color="1A6B3C")

    p_centru = doc.add_paragraph()
    p_centru.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_para_spacing(p_centru, before=0, after=4)
    add_run(p_centru, CENTRU, bold=True, size=11)

    linie_separator(doc)

    p_titlu = doc.add_paragraph()
    p_titlu.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_para_spacing(p_titlu, before=4, after=2)
    add_run(p_titlu, "FIȘĂ DE MONITORIZARE LUNARĂ", bold=True, size=13)

    p_luna = doc.add_paragraph()
    p_luna.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_para_spacing(p_luna, before=0, after=6)
    add_run(p_luna, f"{luna_str.upper()} {an}", bold=True, size=11, color="1A6B3C")

    linie_separator(doc)

    # ── Date identificare ──
    doc.add_paragraph()

    def info(lbl, val):
        p = doc.add_paragraph()
        set_para_spacing(p, before=2, after=2)
        add_run(p, f"{lbl}: ", bold=True, size=10)
        add_run(p, val, size=10)

    info("Nume și prenume beneficiar", benef["nume_complet"])
    info("Diagnostic și grad de handicap",
         f"{benef['diag']} | {benef['grad']}".strip(" |"))
    info("Data începerii găzduirii", benef["sosire"])
    info("Centrul", CENTRU)
    import calendar as _cal
    ultima_zi = _cal.monthrange(an, luna)[1]
    info("Data întocmirii", f"{ultima_zi:02d}.{luna:02d}.{an}")

    linie_separator(doc)

    # ── Secțiuni narative ──
    # 1. Servicii acordate — text standard fix
    adauga_sectiune(doc, "1. Servicii acordate",
        "Găzduire, alimentație, evaluare/reevaluare, informare, "
        "asistență pentru îngrijire personală și sănătate.")

    # 2. Demersuri de asistență socială
    adauga_sectiune(doc, "2. Demersuri de asistență socială",
        text_demersuri_sociale(benef, e))

    # 3. Evaluare și consiliere psihologică
    adauga_sectiune(doc, "3. Evaluare și consiliere psihologică",
        text_consiliere_psihologica(benef, e))

    # 4. Consiliere vocațională
    adauga_sectiune(doc, "4. Consiliere vocațională",
        text_consiliere_vocationala(benef, e))

    # 5. Deprinderi de viață independentă — generat din evaluare
    adauga_sectiune(doc, "5. Deprinderi de viață independentă",
        text_deprinderi(e))

    # 6. Activități desfășurate
    adauga_sectiune(doc, "6. Activități desfășurate",
        text_activitati(benef, e))

    # 7. Demersuri medicale
    p_med = doc.add_paragraph()
    set_para_spacing(p_med, before=6, after=2)
    add_run(p_med, "7. Demersuri medicale:", bold=True, size=10, color="1A6B3C")
    add_run(p_med, "  Staționar din punct de vedere psihic. Urmează tratament "
            "medicamentos conform recomandărilor medicului specialist. ", size=10)
    if benef.get("obs_med"):
        add_run(p_med, benef["obs_med"], size=10)

    # 8. Evaluare risc
    adauga_sectiune(doc, "8. Evaluare risc", text_risc_evaluare(e))

    # 9. Gradul de realizare a obiectivelor
    adauga_sectiune(doc, "9. Gradul de realizare a obiectivelor din Planul Personalizat",
        text_grad_obiective(benef, e))

    # 10. Opinia beneficiarului
    adauga_sectiune(doc, "10. Opinia beneficiarului / reprezentantului legal",
        text_opinie_beneficiar(benef, e))

    # 11. Concluzii și obiective
    adauga_sectiune(doc, "11. Concluzii și obiective pentru perioada următoare",
        text_concluzii(benef, e))

    linie_separator(doc)

    # ── Semnături ──
    doc.add_paragraph()
    p_ech = doc.add_paragraph()
    set_para_spacing(p_ech, before=4, after=8)
    add_run(p_ech, "Echipa multidisciplinară:", bold=True, size=10)

    # Tabel semnături 2x2
    tbl = doc.add_table(rows=2, cols=2)
    tbl.autofit = False
    col_w = Cm(9.0)

    semnaturi = [
        ("Manager de caz", ECHIPA["manager_caz"]),
        ("Asistent social", ECHIPA["asistent_social"]),
        ("Psiholog", ECHIPA["psiholog"]),
        ("Asistent medical", ECHIPA["asistent_medical"]),
    ]

    for idx, (rol, nume_p) in enumerate(semnaturi):
        ri = idx // 2
        ci = idx % 2
        cell = tbl.rows[ri].cells[ci]
        cell.width = col_w
        p = cell.paragraphs[0]
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after  = Pt(4)
        r1 = p.add_run(f"{rol}: ")
        r1.bold = True
        r1.font.size = Pt(9)
        r1.font.name = "Times New Roman"
        r2 = p.add_run(nume_p)
        r2.font.size = Pt(9)
        r2.font.name = "Times New Roman"
        # Linie semnătură
        p2 = cell.add_paragraph()
        p2.paragraph_format.space_before = Pt(0)
        p2.paragraph_format.space_after  = Pt(2)
        r3 = p2.add_run("Semnătură: _____________________")
        r3.font.size = Pt(8)
        r3.font.name = "Times New Roman"

    # Semnătură beneficiar
    doc.add_paragraph()
    p_ben = doc.add_paragraph()
    set_para_spacing(p_ben, before=4, after=2)
    add_run(p_ben, "Beneficiar / Reprezentant legal: ", bold=True, size=9)
    add_run(p_ben, f"{benef['nume_complet']}     ", size=9)
    add_run(p_ben, "Semnătură: _____________________", size=9)


# ── MAIN ──
def adauga_subsol_legal(doc, baza_legala=None):
    """Adaugă baza legală în subsolul documentului — corp 6.5pt, centrat."""
    from docx.shared import Pt, RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    if baza_legala is None:
        baza_legala = (
            "Document generat de CORE v3.0 — o inițiativă SocialHub©  |  "
            "Temei legal: Ord. 82/2019 actualizat prin Ord. 3222/2024 (MMSS)  |  "
            "Legea 292/2011  |  Legea 448/2006  |  "
            "Document editabil — utilizatorul își asumă responsabilitatea "
            "pentru veridicitatea înscrisurilor după semnare și arhivare."
        )
    for section in doc.sections:
        footer = section.footer
        if footer.paragraphs:
            p = footer.paragraphs[0]
            p.clear()
        else:
            p = footer.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after  = Pt(0)
        pPr = p._p.get_or_add_pPr()
        pBdr = OxmlElement("w:pBdr")
        top = OxmlElement("w:top")
        top.set(qn("w:val"), "single"); top.set(qn("w:sz"), "4")
        top.set(qn("w:space"), "1");    top.set(qn("w:color"), "CCCCCC")
        pBdr.append(top); pPr.append(pBdr)
        run = p.add_run(baza_legala)
        run.font.size = Pt(6.5)
        run.font.name = "Times New Roman"
        run.font.color.rgb = RGBColor(0x6B, 0x72, 0x80)


def main():
    luna = int(input("Luna (1-12): ").strip())
    an   = int(input("Anul (ex: 2026): ").strip())

    excel_path = resolve_excel(EXCEL)
    wb = load_workbook(excel_path, data_only=True)

    beneficiari = load_beneficiari(wb)
    eval_map    = load_evaluare(wb)

    print(f"Beneficiari activi: {len(beneficiari)}")

    # ── Folder output organizat ──
    script_dir = Path(__file__).resolve().parent
    luna_str   = LUNI_RO[luna].lower()
    out_dir    = script_dir / "output" / f"{an}_{luna:02d}_{LUNI_RO[luna]}"
    out_dir.mkdir(parents=True, exist_ok=True)
    output_path = out_dir / f"Fise_Monitorizare_Lunara_{luna_str}_{an}.docx"

    # ── Setup document A4 portrait ──
    doc = Document()
    sec = doc.sections[0]
    sec.page_width    = Mm(210)
    sec.page_height   = Mm(297)
    sec.left_margin   = Cm(2.0)
    sec.right_margin  = Cm(2.0)
    sec.top_margin    = Cm(2.0)
    sec.bottom_margin = Cm(2.0)

    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(10)
    style.paragraph_format.space_before = Pt(0)
    style.paragraph_format.space_after  = Pt(4)

    for bi, benef in enumerate(beneficiari):
        print(f"  [{bi+1:02d}/{len(beneficiari)}] {benef['nume_complet']}")
        adauga_fisa(doc, benef, eval_map, luna, an, is_first=(bi == 0))

    adauga_subsol_legal(doc)
    doc.save(str(output_path))
    print(f"\nGata! Generat: {output_path}")
    print(f"Fișe: {len(beneficiari)} beneficiari | {LUNI_RO[luna]} {an}")

if __name__ == "__main__":
    main()
