"""
Generator Fișe Monitorizare Sănătate – CIAPAD Casa Olandeză
Citește din Master Excel (foi: BENEFICIARI + MEDICATIE)
Generează un singur .docx cu toate fișele, fiecare pe pagină impară (față-verso)
"""

from docx import Document
from docx.shared import Cm, Pt, Mm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl import load_workbook
import calendar, datetime
from pathlib import Path
import sys

# ── Configurare ──
EXCEL   = "Master_CORE_v2_CORECTAT.xlsx"
OUTPUT  = None  # se calculează dinamic în main()

LUNI_RO = ["","Ianuarie","Februarie","Martie","Aprilie","Mai","Iunie",
           "Iulie","August","Septembrie","Octombrie","Noiembrie","Decembrie"]

# ── Helpers Excel ──
def norm_key(s):
    import unicodedata, re
    s = str(s).strip().lower()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r'\s+', ' ', s)

def get_headers(ws):
    headers = {}
    row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
    for idx, v in enumerate(row):
        if v is not None:
            headers[norm_key(v)] = idx
    return headers

def find_col(headers, *needles):
    for n in needles:
        nk = norm_key(n)
        if nk in headers:
            return headers[nk]
    for k, idx in headers.items():
        for n in needles:
            if norm_key(n) in k:
                return idx
    return None

def get_sheet(wb, *names):
    lower = {s.lower(): s for s in wb.sheetnames}
    for n in names:
        if n.lower() in lower:
            return wb[lower[n.lower()]]
    return None

def resolve_excel(name):
    # Caută întotdeauna relativ la folderul scriptului
    script_dir = Path(__file__).resolve().parent
    p = script_dir / name
    if p.exists():
        return p
    # Fallback: orice xlsx în același folder
    candidates = sorted(script_dir.glob("*.xlsx"))
    if candidates:
        print(f"Notă: nu găsesc '{name}'. Folosesc: {candidates[0].name}")
        return candidates[0]
    name = input("Introdu numele fișierului Excel (.xlsx): ").strip()
    return script_dir / name

# ── Citire date ──
def load_beneficiari(wb):
    ws = get_sheet(wb, "BENEFICIARI")
    if ws is None:
        raise RuntimeError("Nu găsesc foaia BENEFICIARI.")
    h = get_headers(ws)
    out = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or all(v is None or str(v).strip() == "" for v in row):
            continue
        status = row[find_col(h, "status")] if find_col(h, "status") is not None else None
        if str(status).strip().upper() != "ACTIV":
            continue
        bid   = str(row[find_col(h, "id_beneficiar", "id")]).strip()
        nume  = str(row[find_col(h, "nume")] or "").strip()
        pren  = str(row[find_col(h, "prenume")] or "").strip()
        diag1 = str(row[find_col(h, "diagnostic_principal")] or "").strip()
        diag2 = str(row[find_col(h, "diagnostic_secundar")] or "").strip()
        diag  = " / ".join([d for d in [diag1, diag2] if d])
        out.append({"id": bid, "nume": f"{nume} {pren}".strip(), "diag": diag})
    return out

def load_medicatie(wb):
    ws = get_sheet(wb, "MEDICATIE")
    if ws is None:
        raise RuntimeError("Nu găsesc foaia MEDICATIE în Excel.")
    h = get_headers(ws)
    out = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or all(v is None or str(v).strip() == "" for v in row):
            continue
        activ = str(row[find_col(h, "activ")] or "DA").strip().upper()
        if activ != "DA":
            continue
        bid  = str(row[find_col(h, "id_beneficiar", "id")] or "").strip()
        med  = str(row[find_col(h, "medicament")] or "").strip()
        forma = str(row[find_col(h, "forma", "concentratie", "forma/concentratie")] or "").strip()
        um   = str(row[find_col(h, "unitate_masura", "unitate masura", "um")] or "").strip()
        dim  = row[find_col(h, "dimineata", "dimineață")]
        pranz = row[find_col(h, "pranz", "prânz")]
        seara = row[find_col(h, "seara")]
        adm  = str(row[find_col(h, "administrare")] or "").strip()

        if not bid or not med:
            continue

        # Format schemă: "1+0+1 compr"
        def fmt_doza(v):
            if v is None or str(v).strip() in ("", "0"):
                return "0"
            s = str(v).strip()
            # Afișăm fracții frumos
            try:
                f = float(s)
                return str(int(f)) if f == int(f) else s
            except:
                return s

        schema_text = f"{fmt_doza(dim)}+{fmt_doza(pranz)}+{fmt_doza(seara)}"
        if um:
            schema_text += f" {um}"
        if forma and forma.lower() not in ("compr", "ml", ""):
            schema_text += f" ({forma})"
        if adm:
            schema_text += f" – {adm}"

        # Denumire pentru grila zilnică
        den_grila = med
        if forma and forma.lower() not in ("compr", "sirop", "sol", "solutie", "soluție", ""):
            den_grila += f" {forma}"

        out.setdefault(bid, []).append({
            "medicament": med,
            "forma": forma,
            "um": um,
            "dim": dim,
            "pranz": pranz,
            "seara": seara,
            "schema_text": schema_text,
            "den_grila": den_grila,
            "adm": adm,
        })
    return out

# ── Helpers DOCX ──
def set_cell_borders(cell, top="single", bottom="single", left="single", right="single", sz="6"):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcB = tcPr.find(qn("w:tcBorders"))
    if tcB is None:
        tcB = OxmlElement("w:tcBorders")
        tcPr.append(tcB)
    for edge, val in [("top", top), ("bottom", bottom), ("left", left), ("right", right)]:
        el = tcB.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            tcB.append(el)
        el.set(qn("w:val"), val)
        el.set(qn("w:sz"), sz)
        el.set(qn("w:color"), "000000")
        el.set(qn("w:space"), "0")

def set_cell_shading(cell, fill="D9EAD3"):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = tcPr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcPr.append(shd)
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)

def set_cell_margins(cell, top=60, start=80, bottom=60, end=80):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.find(qn("w:tcMar"))
    if tcMar is None:
        tcMar = OxmlElement("w:tcMar")
        tcPr.append(tcMar)
    for m, v in [("top", top), ("start", start), ("bottom", bottom), ("end", end)]:
        node = tcMar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tcMar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")

def set_row_height(row, height_cm):
    tr = row._tr
    trPr = tr.find(qn("w:trPr"))
    if trPr is None:
        trPr = OxmlElement("w:trPr")
        tr.insert(0, trPr)
    trH = trPr.find(qn("w:trHeight"))
    if trH is None:
        trH = OxmlElement("w:trHeight")
        trPr.append(trH)
    twips = int(height_cm * 567)
    trH.set(qn("w:val"), str(twips))
    trH.set(qn("w:hRule"), "atLeast")

def para_text(cell, text, bold=False, size_pt=9, align=WD_ALIGN_PARAGRAPH.LEFT, color=None):
    for p in cell.paragraphs:
        p.clear()
    p = cell.paragraphs[0]
    p.alignment = align
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(text)
    run.bold = bold
    run.font.size = Pt(size_pt)
    run.font.name = "Times New Roman"
    if color:
        from docx.shared import RGBColor
        run.font.color.rgb = RGBColor.from_string(color)
    return p

def add_odd_page_section(doc):
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    sectPr = section._sectPr
    type_el = sectPr.find(qn("w:type"))
    if type_el is None:
        type_el = OxmlElement("w:type")
        sectPr.insert(0, type_el)
    type_el.set(qn("w:val"), "oddPage")
    # Landscape
    sectPr_pgSz = sectPr.find(qn("w:pgSz"))
    if sectPr_pgSz is None:
        sectPr_pgSz = OxmlElement("w:pgSz")
        sectPr.append(sectPr_pgSz)
    sectPr_pgSz.set(qn("w:w"), str(int(Mm(297).twips)))
    sectPr_pgSz.set(qn("w:h"), str(int(Mm(210).twips)))
    sectPr_pgSz.set(qn("w:orient"), "landscape")
    return section

# ── Generator fișă per beneficiar ──
def adauga_fisa(doc, benef, meds, luna, an, is_first):
    """Adaugă fișa unui beneficiar în document."""
    if not is_first:
        add_odd_page_section(doc)

    zile_luna = calendar.monthrange(an, luna)[1]

    # ── Header ──
    p_titlu = doc.add_paragraph()
    p_titlu.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_titlu.paragraph_format.space_before = Pt(0)
    p_titlu.paragraph_format.space_after = Pt(2)
    run1 = p_titlu.add_run("CIAPAD CASA OLANDEZĂ")
    run1.bold = True
    run1.font.size = Pt(11)
    run1.font.name = "Times New Roman"
    run1.add_tab()
    run2 = p_titlu.add_run("FIȘĂ DE MONITORIZARE A STĂRII DE SĂNĂTATE")
    run2.bold = True
    run2.font.size = Pt(11)
    run2.font.name = "Times New Roman"

    def info_line(label, value, bold_val=True):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(1)
        r1 = p.add_run(label)
        r1.bold = True
        r1.font.size = Pt(10)
        r1.font.name = "Times New Roman"
        r2 = p.add_run(value)
        r2.bold = bold_val
        r2.font.size = Pt(10)
        r2.font.name = "Times New Roman"

    info_line("NUME/PRENUME BENEFICIAR:  ", benef["nume"])
    info_line("DIAGNOSTIC:  ", benef["diag"], bold_val=False)
    info_line("LUNA: ", f"{LUNI_RO[luna]}     ANUL: {an}")

    doc.add_paragraph().paragraph_format.space_after = Pt(2)

    # ── Schema tratament (text) ──
    schema_linii = []
    for m in meds:
        schema_linii.append(f"{m['medicament']} {m['forma']}  {m['schema_text']}")
    schema_str = "     ".join(schema_linii) if schema_linii else "—"

    p_schema = doc.add_paragraph()
    p_schema.paragraph_format.space_before = Pt(0)
    p_schema.paragraph_format.space_after = Pt(3)
    rs = p_schema.add_run("SCHEMA TRATAMENT CRONIC:  ")
    rs.bold = True
    rs.font.size = Pt(9)
    rs.font.name = "Times New Roman"
    rv = p_schema.add_run(schema_str)
    rv.font.size = Pt(9)
    rv.font.name = "Times New Roman"

    # ── Tabelul de sus (informații lunare) ──
    # 4 rânduri x 7 coloane
    # Lățimi în cm (total ~25.4cm landscape cu margini 1.3)
    W_TOTAL = Cm(25.4)
    col_widths_sus = [Cm(3.0), Cm(4.0), Cm(6.5), Cm(4.0), Cm(2.8), Cm(2.8), Cm(2.3)]

    tbl_sus = doc.add_table(rows=4, cols=7)
    tbl_sus.autofit = False
    tbl_sus.style = "Table Grid"

    # Header rând 0
    headers_sus = [
        "Stare de\nsănătate",
        "Tensiune/\ntemperatură",
        "Schema de\nTratament cronic",
        "Consultații\nProgramate /\nUrgență / 112",
        "Regim\nalimentar",
        "Internări",
        "Alte situații\nRefuzul\ntratamentului"
    ]
    for ci, (txt, w) in enumerate(zip(headers_sus, col_widths_sus)):
        cell = tbl_sus.rows[0].cells[ci]
        cell.width = w
        para_text(cell, txt, bold=True, size_pt=8, align=WD_ALIGN_PARAGRAPH.CENTER)
        set_cell_shading(cell, "1C6B3C")
        # Schimbă culoarea textului la alb
        for p in cell.paragraphs:
            for run in p.runs:
                from docx.shared import RGBColor
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_borders(cell)
        set_cell_margins(cell, top=60, start=60, bottom=60, end=60)
        set_row_height(tbl_sus.rows[0], 1.0)

    # Rând 1 — schema tratament în col 2, restul goale
    schema_tabel = "\n".join([f"{m['medicament']} {m['forma']}  {m['schema_text']}" for m in meds])
    for ci, w in enumerate(col_widths_sus):
        cell = tbl_sus.rows[1].cells[ci]
        cell.width = w
        val = schema_tabel if ci == 2 else ""
        para_text(cell, val, size_pt=8)
        set_cell_borders(cell)
        set_cell_margins(cell)
        set_row_height(tbl_sus.rows[1], 1.5)

    # Rânduri 2 și 3 — etichete fixe + spații libere
    etichete_r2 = ["Boli\nAcute", "Simptome\nPrezentate\n\n", "", "", "Alergii", "Accidentări", ""]
    etichete_r3 = ["", "", "", "", "Imunizări", "Situații de\nPrim ajutor", ""]

    for ci, (e2, e3, w) in enumerate(zip(etichete_r2, etichete_r3, col_widths_sus)):
        for ri, eticheta in [(2, e2), (3, e3)]:
            cell = tbl_sus.rows[ri].cells[ci]
            cell.width = w
            bold = ci in (0, 1, 4, 5) and ri == 2 or ci in (4, 5) and ri == 3
            para_text(cell, eticheta, bold=bold, size_pt=8)
            set_cell_borders(cell)
            set_cell_margins(cell)
            set_row_height(tbl_sus.rows[ri], 0.9)

    doc.add_paragraph().paragraph_format.space_after = Pt(4)

    # ── Titlu grilă ──
    p_gr = doc.add_paragraph()
    p_gr.paragraph_format.space_before = Pt(0)
    p_gr.paragraph_format.space_after = Pt(2)
    rg = p_gr.add_run("TRATAMENT / ZI")
    rg.bold = True
    rg.font.size = Pt(10)
    rg.font.name = "Times New Roman"

    # ── Grila zilnică ──
    # 1 col medicament (3.5cm) + 31 zile + col UM (1.2cm)
    # Total coloane: 33
    N_ROWS_MED = 8  # fix 8 rânduri pentru medicamente
    N_COLS = 33     # col0=medicament, col1..31=zile, col32=UM

    w_med = Cm(3.8)
    w_um  = Cm(1.0)
    w_zi  = Cm((25.4 - 3.8 - 1.0) / 31)  # ~0.664 cm per zi

    tbl_zi = doc.add_table(rows=N_ROWS_MED + 1, cols=N_COLS)
    tbl_zi.autofit = False
    tbl_zi.style = "Table Grid"

    # Rând header (zilele 1-31)
    hdr = tbl_zi.rows[0]
    set_row_height(hdr, 0.55)
    # Col 0 = gol
    c0 = hdr.cells[0]
    c0.width = w_med
    para_text(c0, "Medicament", bold=True, size_pt=7.5, align=WD_ALIGN_PARAGRAPH.CENTER)
    set_cell_shading(c0, "1C6B3C")
    for p in c0.paragraphs:
        for run in p.runs:
            from docx.shared import RGBColor
            run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    set_cell_borders(c0)
    set_cell_margins(c0, top=40, start=40, bottom=40, end=40)

    # Zilele 1-31
    for zi in range(1, 32):
        cell = hdr.cells[zi]
        cell.width = w_zi
        # Marchează duminicile și sămbetele (culoare ușoară)
        try:
            wd = datetime.date(an, luna, zi).weekday()
            fill = "FCE5CD" if wd == 6 else ("FFF2CC" if wd == 5 else "D9EAD3")
        except ValueError:
            fill = "EEEEEE"  # zi inexistentă (ex. 31 feb)
        para_text(cell, str(zi), bold=True, size_pt=7, align=WD_ALIGN_PARAGRAPH.CENTER)
        set_cell_shading(cell, fill)
        set_cell_borders(cell)
        set_cell_margins(cell, top=30, start=20, bottom=30, end=20)

    # Col 32 = UM header
    cum = hdr.cells[32]
    cum.width = w_um
    para_text(cum, "U.M.", bold=True, size_pt=7, align=WD_ALIGN_PARAGRAPH.CENTER)
    set_cell_shading(cum, "1C6B3C")
    for p in cum.paragraphs:
        for run in p.runs:
            from docx.shared import RGBColor
            run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    set_cell_borders(cum)
    set_cell_margins(cum, top=40, start=20, bottom=40, end=20)

    # Rânduri medicamente
    for ri in range(1, N_ROWS_MED + 1):
        row = tbl_zi.rows[ri]
        set_row_height(row, 0.65)
        med_idx = ri - 1
        med = meds[med_idx] if med_idx < len(meds) else None

        # Col 0 — numele medicamentului
        c_med = row.cells[0]
        c_med.width = w_med
        den = med["den_grila"] if med else ""
        fill_med = "EAF4EE" if med_idx % 2 == 0 else "FFFFFF"
        para_text(c_med, den, bold=bool(med), size_pt=8)
        set_cell_shading(c_med, fill_med)
        set_cell_borders(c_med)
        set_cell_margins(c_med, top=30, start=60, bottom=30, end=40)

        # Calculează doza pentru celulele zilnice
        def fmt_d(v):
            if v is None: return "0"
            try:
                f = float(v)
                return str(int(f)) if f == int(f) else str(f)
            except:
                return str(v).strip() or "0"

        doza_celula = ""
        if med:
            d = fmt_d(med["dim"])
            p = fmt_d(med["pranz"])
            s = fmt_d(med["seara"])
            if not (d == "0" and p == "0" and s == "0"):
                doza_celula = f"{d}/{p}/{s}"

        # Zilele 1-31
        for zi in range(1, 32):
            cell = row.cells[zi]
            cell.width = w_zi
            try:
                datetime.date(an, luna, zi)
                zi_valida = True
                fill_zi = fill_med
            except ValueError:
                zi_valida = False
                fill_zi = "CCCCCC"
            val = doza_celula if zi_valida else ""
            para_text(cell, val, size_pt=6.5, align=WD_ALIGN_PARAGRAPH.CENTER)
            set_cell_shading(cell, fill_zi)
            set_cell_borders(cell)
            set_cell_margins(cell, top=20, start=10, bottom=20, end=10)

        # Col 32 — unitate măsură
        c_um = row.cells[32]
        c_um.width = w_um
        um_val = med["um"] if med else ""
        para_text(c_um, um_val, size_pt=7.5, align=WD_ALIGN_PARAGRAPH.CENTER)
        set_cell_shading(c_um, fill_med)
        set_cell_borders(c_um)
        set_cell_margins(c_um, top=30, start=20, bottom=30, end=20)


# ── MAIN ──
def adauga_subsol_legal(doc, baza_legala=None):
    """Adaugă baza legală în subsolul documentului — corp 6.5pt, centrat."""
    from docx.shared import Pt, RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    if baza_legala is None:
        baza_legala = (
            "Document generat de CORE v3.0 — o inițiativă SocialHub©  |  "
            "Temei legal: Ord. 82/2019 actualizat prin Ord. 3222/2024 (MMSS)  |  "
            "Legea 292/2011  |  Legea 448/2006  |  "
            "Document editabil — utilizatorul își asumă responsabilitatea "
            "pentru veridicitatea înscrisurilor după semnare și arhivare."
        )
    for section in doc.sections:
        footer = section.footer
        if footer.paragraphs:
            p = footer.paragraphs[0]
            p.clear()
        else:
            p = footer.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after  = Pt(0)
        pPr = p._p.get_or_add_pPr()
        pBdr = OxmlElement("w:pBdr")
        top = OxmlElement("w:top")
        top.set(qn("w:val"), "single"); top.set(qn("w:sz"), "4")
        top.set(qn("w:space"), "1");    top.set(qn("w:color"), "CCCCCC")
        pBdr.append(top); pPr.append(pBdr)
        run = p.add_run(baza_legala)
        run.font.size = Pt(6.5)
        run.font.name = "Times New Roman"
        run.font.color.rgb = RGBColor(0x6B, 0x72, 0x80)


def main():
    luna = int(input("Luna (1-12): ").strip())
    an   = int(input("Anul (ex: 2026): ").strip())

    excel_path = resolve_excel(EXCEL)
    wb = load_workbook(excel_path, data_only=True)

    beneficiari = load_beneficiari(wb)
    medicatie   = load_medicatie(wb)

    print(f"Beneficiari activi: {len(beneficiari)}")

    # ── Folder output organizat ──
    script_dir = Path(__file__).resolve().parent
    luna_str   = LUNI_RO[luna].lower()
    out_dir    = script_dir / "output" / f"{an}_{luna:02d}_{LUNI_RO[luna]}"
    out_dir.mkdir(parents=True, exist_ok=True)
    output_path = out_dir / f"Fise_Monitorizare_Sanatate_{luna_str}_{an}.docx"

    # Setup document — landscape A4
    doc = Document()
    sec = doc.sections[0]
    sec.page_width  = Mm(297)
    sec.page_height = Mm(210)
    sec.left_margin   = Cm(1.3)
    sec.right_margin  = Cm(1.3)
    sec.top_margin    = Cm(1.3)
    sec.bottom_margin = Cm(1.3)
    # Orientare landscape în XML
    sectPr = sec._sectPr
    pgSz = sectPr.find(qn("w:pgSz"))
    if pgSz is None:
        pgSz = OxmlElement("w:pgSz")
        sectPr.append(pgSz)
    pgSz.set(qn("w:orient"), "landscape")

    # Font implicit
    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(10)
    style.paragraph_format.space_before = Pt(0)
    style.paragraph_format.space_after  = Pt(0)

    for bi, benef in enumerate(beneficiari):
        bid  = benef["id"]
        meds = medicatie.get(bid, [])
        print(f"  [{bi+1:02d}/{len(beneficiari)}] {benef['nume']} — {len(meds)} medicamente")
        adauga_fisa(doc, benef, meds, luna, an, is_first=(bi == 0))

    adauga_subsol_legal(doc)
    doc.save(str(output_path))
    print(f"\nGata! Generat: {output_path}")
    print(f"Fișe: {len(beneficiari)} beneficiari | {LUNI_RO[luna]} {an}")

if __name__ == "__main__":
    main()
