"""
CORE – Interfață grafică v2.0
Panou de control: Fișe Sprijin Continuu ORD 82 + Fișe Monitorizare Sănătate
Autor: generat cu asistență Claude (Anthropic)
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import subprocess
import sys
import os
import shutil
import datetime
import calendar
from pathlib import Path
try:
    import core_termeni as _tc
except ImportError:
    _tc = None

try:
    import core_update as _upd
except ImportError:
    _upd = None

# ──────────────────────────────────────────────
# CONFIGURARE
# ──────────────────────────────────────────────
CULORI = {
    "fundal":       "#F5F7FA",
    "card":         "#FFFFFF",
    "primar":       "#1A6B3C",
    "primar_hover": "#145530",
    "accent":       "#2E9E5E",
    "text":         "#1C1C1E",
    "text_sec":     "#6B7280",
    "border":       "#E5E7EB",
    "succes":       "#059669",
    "eroare":       "#DC2626",
    "atentie":      "#D97706",
    "bar_bg":       "#E5E7EB",
    "bar_fill":     "#1A6B3C",
    "tab_activ":    "#1A6B3C",
    "tab_inactiv":  "#E5E7EB",
}

FONT_TITLU    = ("Segoe UI", 20, "bold")
FONT_SUBTITLU = ("Segoe UI", 11)
FONT_LABEL    = ("Segoe UI", 10, "bold")
FONT_NORMAL   = ("Segoe UI", 10)
FONT_MIC      = ("Segoe UI", 9)
FONT_BTN      = ("Segoe UI", 10, "bold")

LUNI = ["", "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"]

APP_VERSION   = "3.0"
APP_BRANDING  = "o inițiativă SocialHub©"
APP_COPYRIGHT = f"© 2026 {APP_BRANDING} — Uz intern exclusiv"

# Configurare generatoare — adaugă orice generator nou doar aici
GENERATOARE = [
    {
        "id":       "sprijin",
        "titlu":    "Fișe Sprijin Continuu",
        "subtitlu": "Monitorizare activități zilnice • ORD 82",
        "icon":     "📋",
        "script":   "genereaza_fise_sprijin_continuu.py",
        "prefix":   "Fise_Sprijin_Continuu",
    },
    {
        "id":       "sanatate",
        "titlu":    "Fișe Monitorizare Sănătate",
        "subtitlu": "Tratament zilnic • CIAPAD Casa Olandeză",
        "icon":     "🏥",
        "script":   "genereaza_fise_sanatate.py",
        "prefix":   "Fise_Monitorizare_Sanatate",
    },
    {
        "id":       "monitorizare",
        "titlu":    "Fișe Monitorizare Lunară",
        "subtitlu": "Raport lunar per beneficiar • ORD 82 / Ord. 3222/2024",
        "icon":     "📝",
        "script":   "genereaza_fise_monitorizare_lunara.py",
        "prefix":   "Fise_Monitorizare_Lunara",
    },
    {
        "id":       "condica",
        "titlu":    "Condică Medicamente",
        "subtitlu": "Prescripții și materiale sanitare • totalizator lunar",
        "icon":     "💊",
        "script":   "genereaza_condica_medicamente.py",
        "prefix":   "Condica_Medicamente",
    },
]

# ──────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────
def cale_relativa(fisier):
    baza = Path(__file__).resolve().parent
    return baza / fisier

def backup_excel(excel_path):
    backup_dir = Path(excel_path).parent / "backup"
    backup_dir.mkdir(exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = backup_dir / f"Master_backup_{ts}.xlsx"
    shutil.copy2(excel_path, dest)
    backups = sorted(backup_dir.glob("Master_backup_*.xlsx"))
    for vechi in backups[:-10]:
        vechi.unlink()
    return dest

def folder_output_luna(luna, an):
    """Returnează calea folderului output pentru luna/an."""
    script_dir = Path(__file__).resolve().parent
    return script_dir / "output" / f"{an}_{luna:02d}_{LUNI[luna]}"

# ──────────────────────────────────────────────
# WIDGET-URI PERSONALIZATE
# ──────────────────────────────────────────────
class BtnPrimar(tk.Button):
    def __init__(self, parent, **kwargs):
        opts = dict(bg=CULORI["primar"], fg="white",
                    activebackground=CULORI["primar_hover"], activeforeground="white",
                    relief="flat", cursor="hand2", padx=20, pady=10, font=FONT_BTN)
        opts.update(kwargs)
        super().__init__(parent, **opts)
        self.bind("<Enter>", lambda e: self.config(bg=CULORI["primar_hover"]))
        self.bind("<Leave>", lambda e: self.config(bg=CULORI["primar"]))

class BtnSecundar(tk.Button):
    def __init__(self, parent, **kwargs):
        opts = dict(bg=CULORI["card"], fg=CULORI["primar"],
                    activebackground=CULORI["border"], activeforeground=CULORI["primar"],
                    relief="flat", cursor="hand2", padx=16, pady=8, font=FONT_BTN,
                    bd=1, highlightthickness=1, highlightbackground=CULORI["primar"])
        opts.update(kwargs)
        super().__init__(parent, **opts)
        self.bind("<Enter>", lambda e: self.config(bg=CULORI["border"]))
        self.bind("<Leave>", lambda e: self.config(bg=CULORI["card"]))

class Card(tk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, bg=CULORI["card"], relief="flat", bd=0,
                         highlightthickness=1, highlightbackground=CULORI["border"], **kwargs)

# ──────────────────────────────────────────────
# PANOUL UNUI GENERATOR (tab)
# ──────────────────────────────────────────────
class PanouGenerator(tk.Frame):
    """Un panou complet pentru un tip de fișă — reutilizabil pentru orice generator."""

    def __init__(self, parent, app, config_gen, **kwargs):
        super().__init__(parent, bg=CULORI["fundal"], **kwargs)
        self.app        = app          # referință la AppCORE pentru log și status
        self.config_gen = config_gen
        self.generare_activa = False
        self.dest_final_last = None

        self._construieste()

    def _construieste(self):
        pad = {"padx": 20, "pady": 10}

        # ── Card perioadă ──
        card_per = Card(self, padx=16, pady=14)
        card_per.pack(fill="x", **pad)

        tk.Label(card_per, text="📅  Perioadă de generare", font=FONT_LABEL,
                 bg=CULORI["card"], fg=CULORI["text"]).pack(anchor="w", pady=(0, 10))

        rand = tk.Frame(card_per, bg=CULORI["card"])
        rand.pack(fill="x")

        tk.Label(rand, text="Luna:", font=FONT_NORMAL, bg=CULORI["card"],
                 fg=CULORI["text"], width=6, anchor="w").pack(side="left")
        self.cmb_luna = ttk.Combobox(rand, values=LUNI[1:], state="readonly",
                                      width=14, font=FONT_NORMAL)
        self.cmb_luna.current(datetime.date.today().month - 1)
        self.cmb_luna.pack(side="left", padx=(0, 24))

        tk.Label(rand, text="Anul:", font=FONT_NORMAL, bg=CULORI["card"],
                 fg=CULORI["text"], width=5, anchor="w").pack(side="left")
        self.an_var = tk.IntVar(value=datetime.date.today().year)
        self.spn_an = tk.Spinbox(rand, from_=2020, to=2040, textvariable=self.an_var,
                                  width=8, font=FONT_NORMAL, relief="flat", bd=1)
        self.spn_an.pack(side="left")

        self.lbl_rezumat = tk.Label(card_per, text="", font=FONT_MIC,
                                     bg=CULORI["card"], fg=CULORI["text_sec"])
        self.lbl_rezumat.pack(anchor="w", pady=(8, 0))

        self.cmb_luna.bind("<<ComboboxSelected>>", lambda e: self._actualizeaza_rezumat())
        self.an_var.trace_add("write", lambda *_: self._actualizeaza_rezumat())
        self._actualizeaza_rezumat()

        # ── Card acțiuni ──
        card_act = Card(self, padx=16, pady=14)
        card_act.pack(fill="x", padx=20, pady=(0, 10))

        tk.Label(card_act, text="⚙️  Generare", font=FONT_LABEL,
                 bg=CULORI["card"], fg=CULORI["text"]).pack(anchor="w", pady=(0, 10))

        rand_btn = tk.Frame(card_act, bg=CULORI["card"])
        rand_btn.pack(fill="x")

        self.btn_genereaza = BtnPrimar(rand_btn,
                                        text=f"▶  Generează {self.config_gen['titlu']}",
                                        command=self._incepe_generare)
        self.btn_genereaza.pack(side="left")

        self.btn_deschide = tk.Button(
            rand_btn, text="📄  Deschide documentul",
            font=FONT_BTN, relief="flat", cursor="hand2",
            padx=18, pady=10, state="disabled",
            bg=CULORI["fundal"], fg=CULORI["text_sec"],
            activebackground=CULORI["primar_hover"], activeforeground="white",
            bd=1, highlightthickness=1, highlightbackground=CULORI["border"],
            command=self._deschide_doc
        )
        self.btn_deschide.pack(side="left", padx=(10, 0))

        self.btn_folder = BtnSecundar(rand_btn, text="📂  Folder output",
                                       command=self._deschide_folder,
                                       pady=10, padx=14)
        self.btn_folder.pack(side="left", padx=(10, 0))

        # Bara progres
        tk.Frame(card_act, bg=CULORI["card"], height=10).pack()
        self.canvas_bar = tk.Canvas(card_act, height=10, bg=CULORI["bar_bg"],
                                     highlightthickness=0)
        self.canvas_bar.pack(fill="x")
        self.rect_bar = self.canvas_bar.create_rectangle(0, 0, 0, 10,
                                                          fill=CULORI["bar_fill"], outline="")
        self.canvas_bar.bind("<Configure>", lambda e: self._seteaza_progres(self._progres))
        self._progres = 0.0

        tk.Frame(card_act, bg=CULORI["card"], height=4).pack()
        self.lbl_progres = tk.Label(card_act, text="", font=FONT_MIC,
                                     bg=CULORI["card"], fg=CULORI["text_sec"])
        self.lbl_progres.pack(anchor="w")

    def _luna(self):
        return LUNI.index(self.cmb_luna.get())

    def _an(self):
        return self.an_var.get()

    def _actualizeaza_rezumat(self):
        try:
            luna = self._luna()
            an   = self._an()
            zile = calendar.monthrange(an, luna)[1]
            self.lbl_rezumat.config(
                text=f"{LUNI[luna]} {an}  •  {zile} zile  •  20 beneficiari")
        except Exception:
            pass

    def _seteaza_progres(self, val):
        self._progres = val
        w = self.canvas_bar.winfo_width()
        if w > 1:
            x2 = int(w * val / 100)
            self.canvas_bar.coords(self.rect_bar, 0, 0, x2, 10)

    def _deschide_doc(self):
        if self.dest_final_last and Path(self.dest_final_last).exists():
            os.startfile(str(self.dest_final_last))
        else:
            # Caută cel mai recent în folderul lunii curente
            out_dir = folder_output_luna(self._luna(), self._an())
            prefix  = self.config_gen["prefix"]
            fisiere = sorted(out_dir.glob(f"{prefix}*.docx"),
                             key=os.path.getmtime, reverse=True)
            if fisiere:
                os.startfile(str(fisiere[0]))
            else:
                messagebox.showinfo("Info", "Nu am găsit fișierul generat.\nVerifică folderul output.")

    def _deschide_folder(self):
        out_dir = folder_output_luna(self._luna(), self._an())
        out_dir.mkdir(parents=True, exist_ok=True)
        os.startfile(str(out_dir))

    # ── Generare ──
    def _incepe_generare(self):
        if self.generare_activa:
            return

        excel  = self.app._get_excel_path()
        script = cale_relativa(self.config_gen["script"])
        luna   = self._luna()
        an     = self._an()

        if not excel.exists():
            messagebox.showerror("Eroare", f"Nu găsesc fișierul Excel:\n{excel}")
            return
        if not script.exists():
            messagebox.showerror("Eroare",
                f"Nu găsesc scriptul:\n{script}\n\nVerifică că fișierul există în același folder cu GUI-ul.")
            return

        confirmare = messagebox.askyesno(
            "Confirmare generare",
            f"Se vor genera:\n\n"
            f"  {self.config_gen['icon']}  {self.config_gen['titlu']}\n"
            f"  Luna:  {LUNI[luna]} {an}\n"
            f"  Excel: {excel.name}\n\n"
            f"Se va face backup automat al bazei de date.\n\nContinui?"
        )
        if not confirmare:
            return

        self.generare_activa = True
        self.btn_genereaza.config(state="disabled", text="⏳  Generare în curs...")
        self.btn_deschide.config(state="disabled")
        self._seteaza_progres(0)
        self.lbl_progres.config(text="", fg=CULORI["text_sec"])
        self.app.status_var.set(f"Generare {self.config_gen['titlu']}...")

        thread = threading.Thread(
            target=self._ruleaza_generator,
            args=(luna, an, excel, script),
            daemon=True
        )
        thread.start()

    def _ruleaza_generator(self, luna, an, excel, script):
        try:
            self.app.log(f"{'─'*40}", "info")
            self.app.log(f"{self.config_gen['icon']}  {self.config_gen['titlu']} — {LUNI[luna]} {an}", "titlu")

            # Backup
            self.app.log("Fac backup al bazei de date...", "info")
            dest_backup = backup_excel(excel)
            self.app.log(f"✓ Backup: {dest_backup.name}", "ok")
            self.after(0, self._seteaza_progres, 15)

            # Rulare script
            self.app.log(f"Pornesc generatorul...", "info")
            intrare = f"{luna}\n{an}\n"
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"

            result = subprocess.run(
                [sys.executable, str(script)],
                input=intrare,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                cwd=str(script.parent),
                env=env,
                timeout=300
            )

            self.after(0, self._seteaza_progres, 90)

            if result.returncode != 0:
                eroare = result.stderr or result.stdout or "Eroare necunoscută."
                self.app.log(f"✗ Eroare:\n{eroare}", "eroare")
                self.after(0, self._finalizare_eroare, eroare)
                return

            # Găsim fișierul generat în output/
            luna_str  = LUNI[luna].lower()
            out_dir   = folder_output_luna(luna, an)
            prefix    = self.config_gen["prefix"]
            dest_final = out_dir / f"{prefix}_{luna_str}_{an}.docx"

            if dest_final.exists():
                self.app.log(f"✓ Generat: {dest_final.name}", "ok")
                self.app.log(f"  📁 {dest_final.parent}", "info")
            else:
                # Fallback: caută orice fișier cu prefixul corect
                candidati = sorted(out_dir.glob(f"{prefix}*.docx"),
                                   key=os.path.getmtime, reverse=True)
                if candidati:
                    dest_final = candidati[0]
                    self.app.log(f"✓ Generat: {dest_final.name}", "ok")
                else:
                    self.app.log("⚠ Scriptul a rulat dar fișierul output nu a fost găsit.", "eroare")

            if result.stdout:
                for linie in result.stdout.strip().split("\n"):
                    if linie.strip() and "Luna" not in linie and "Anul" not in linie:
                        self.app.log(f"   {linie}", "info")

            self.after(0, self._seteaza_progres, 100)
            self.after(0, self._finalizare_succes, dest_final)

        except subprocess.TimeoutExpired:
            self.app.log("✗ Timeout: generarea a durat prea mult.", "eroare")
            self.after(0, self._finalizare_eroare, "Timeout.")
        except Exception as ex:
            self.app.log(f"✗ Excepție: {ex}", "eroare")
            self.after(0, self._finalizare_eroare, str(ex))

    def _finalizare_succes(self, dest_final):
        self.generare_activa = False
        self.dest_final_last = dest_final
        luna = self._luna()
        an   = self._an()
        import calendar as _cal
        zile = _cal.monthrange(an, luna)[1]
        self.btn_genereaza.config(state="normal",
                                   text=f"▶  Generează {self.config_gen['titlu']}")
        # Buton deschide devine verde și prominent
        self.btn_deschide.config(
            state="normal",
            bg=CULORI["primar"], fg="white",
            highlightbackground=CULORI["primar"],
            text="✅  Deschide documentul generat"
        )
        self.btn_deschide.bind("<Enter>",
            lambda e: self.btn_deschide.config(bg=CULORI["primar_hover"]))
        self.btn_deschide.bind("<Leave>",
            lambda e: self.btn_deschide.config(bg=CULORI["primar"]))
        self.lbl_progres.config(
            text=f"✓ {self.config_gen['titlu']} — {LUNI[luna]} {an} — {zile} zile — generat cu succes",
            fg=CULORI["succes"])
        self.app.status_var.set(f"✓ Gata: {self.config_gen['titlu']} {LUNI[luna]} {an}")
        messagebox.showinfo("Generare finalizată ✓",
            f"{self.config_gen['icon']}  {self.config_gen['titlu']}\n\n"
            f"Au fost generate fișele pentru {LUNI[luna]} {an}.\n"
            f"({zile} zile — 20 beneficiari)\n\n"
            f"Documentul a fost salvat în:\n"
            f"output/{an}_{luna:02d}_{LUNI[luna]}/\n\n"
            f"Apasă butonul verde pentru a-l deschide.")

    def _finalizare_eroare(self, mesaj):
        self.generare_activa = False
        self.btn_genereaza.config(state="normal",
                                   text=f"▶  Generează {self.config_gen['titlu']}")
        self.lbl_progres.config(text=f"✗ {mesaj[:80]}", fg=CULORI["eroare"])
        self.app.status_var.set("✗ Eroare la generare.")
        messagebox.showerror("Eroare",
            f"A apărut o eroare:\n\n{mesaj}\n\nVerifică jurnalul pentru detalii.")


# ──────────────────────────────────────────────
# FEREASTRA PRINCIPALĂ
# ──────────────────────────────────────────────
class AppCORE(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title(f"CORE v{APP_VERSION} — Sistem Generare Fișe Beneficiari")
        self.geometry("900x700")
        self.minsize(820, 580)
        self.configure(bg=CULORI["fundal"])
        self.resizable(True, True)

        self.update_idletasks()
        lx = (self.winfo_screenwidth()  - 820) // 2
        ly = (self.winfo_screenheight() - 700) // 2
        self.geometry(f"820x700+{lx}+{ly}")

        self._excel_nume = "Master_CORE_v2_CORECTAT.xlsx"
        self._excel_cale_default = Path(__file__).resolve().parent / self._excel_nume
        self.excel_var  = tk.StringVar(value=str(self._excel_cale_default))
        self.status_var = tk.StringVar(value="Pregătit.")

        self._construieste_ui()
        self.after(200, self._verifica_fisiere)
        # Verifică acordul T&C la prima rulare
        self.after(300, self._verifica_termeni)
        # Lansează verificarea online în fundal
        if _upd:
            _upd.porneste_verificare(
                callback=lambda r: self.after(0, self._proceseaza_update, r))

    def _get_excel_path(self):
        """Returnează calea Excel validă — preferă calea default față de scriptului."""
        # Întâi încearcă calea stocată în excel_var
        p = Path(self.excel_var.get())
        if p.exists():
            return p
        # Fallback: calea calculată la pornire față de locul scriptului
        if hasattr(self, '_excel_cale_default') and self._excel_cale_default.exists():
            self.excel_var.set(str(self._excel_cale_default))
            try:
                self.lbl_excel_nume.config(text=self._excel_cale_default.name)
            except Exception:
                pass
            return self._excel_cale_default
        return p

    def _proceseaza_update(self, rezultat):
        """Procesează rezultatul verificării online."""
        if not rezultat.get("verificat"):
            return
        if not rezultat.get("online"):
            # Verifică dacă e avertisment offline prelungit
            if rezultat.get("status") == "avertisment_offline":
                self.log(f"⚠ {rezultat.get('mesaj', '')}", "atentie")
            return
        # Verifică blocare
        if _upd and _upd.este_blocat():
            import tkinter.messagebox as mb
            mesaj = _upd.get_mesaj_blocare()
            self.log(f"✗ {mesaj}", "eroare")
            mb.showerror("Aplicație dezactivată", mesaj)
            # Dezactivează toate butoanele de generare
            for panou in self.tab_panouri:
                panou.btn_genereaza.config(
                    state="disabled",
                    text="✕  Generare dezactivată")
            return
        # Versiune nouă disponibilă
        v_noua = rezultat.get("versiune_noua")
        if v_noua:
            self.log(
                f"📦 Versiune nouă disponibilă: CORE v{v_noua}. "
                f"Contactați administratorul pentru actualizare.", "atentie")
            self.status_var.set(
                f"⚠ Versiune nouă disponibilă: CORE v{v_noua}")
        else:
            self.log("✓ Licență verificată — aplicație activă și actualizată.", "ok")

    def _verifica_termeni(self):
        """Afișează T&C la prima rulare."""
        if _tc is None:
            return
        if not _tc.este_acceptat():
            from core_termeni import FerTermeni
            FerTermeni(self, lambda: self.log(
                "✓ Termeni și condiții acceptați. Bun venit în CORE!", "ok"))

    # ── UI ──
    def _construieste_ui(self):
        # Header
        header = tk.Frame(self, bg=CULORI["primar"])
        header.pack(fill="x")

        tk.Label(header, text="⚕  CORE", font=FONT_TITLU,
                 bg=CULORI["primar"], fg="white").pack(side="left", padx=24, pady=14)
        tk.Label(header, text=f"Sistem de generare fișe beneficiari • Casa Olandeză  |  {APP_BRANDING}",
                 font=FONT_SUBTITLU, bg=CULORI["primar"],
                 fg="#A7D9BA").pack(side="left", padx=4)

        # Corp
        corp = tk.Frame(self, bg=CULORI["fundal"])
        corp.pack(fill="both", expand=True, padx=20, pady=16)

        # Secțiunea fișiere (comună tuturor generatoarelor)
        self._sectiune_fisiere(corp)
        tk.Frame(corp, bg=CULORI["fundal"], height=10).pack()

        # Notebook cu tab-uri pentru fiecare generator
        self._construieste_tabs(corp)

        tk.Frame(corp, bg=CULORI["fundal"], height=8).pack()

        # Log
        self._sectiune_log(corp)

        # Footer
        footer = tk.Frame(self, bg=CULORI["border"], height=30)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        tk.Label(footer, textvariable=self.status_var, font=FONT_MIC,
                 bg=CULORI["border"], fg=CULORI["text_sec"]).pack(side="left", padx=16, pady=6)
        tk.Label(footer, text=APP_COPYRIGHT, font=FONT_MIC,
                 bg=CULORI["border"], fg=CULORI["text_sec"]).pack(side="right", padx=16, pady=6)

    def _sectiune_fisiere(self, parinte):
        card = Card(parinte, padx=16, pady=12)
        card.pack(fill="x")

        tk.Label(card, text="📁  Bază de date", font=FONT_LABEL,
                 bg=CULORI["card"], fg=CULORI["text"]).pack(anchor="w", pady=(0, 8))

        rand = tk.Frame(card, bg=CULORI["card"])
        rand.pack(fill="x")

        tk.Label(rand, text="Fișier Excel (Master):", font=FONT_NORMAL,
                 bg=CULORI["card"], fg=CULORI["text"], width=22, anchor="w").pack(side="left")

        # Afișăm doar numele fișierului, nu calea completă
        self.lbl_excel_nume = tk.Label(rand, text=self._excel_nume, font=FONT_MIC,
                 bg=CULORI["fundal"], fg=CULORI["text_sec"],
                 relief="flat", padx=8, anchor="w")
        self.lbl_excel_nume.pack(side="left", fill="x", expand=True, ipady=4)

        BtnSecundar(rand, text="Alege...", command=self._alege_excel,
                    pady=4, padx=10).pack(side="right", padx=(8, 0))

        # Buton editare directă Excel
        rand2 = tk.Frame(card, bg=CULORI["card"])
        rand2.pack(fill="x", pady=(8, 0))
        btn_ex = tk.Button(
            rand2, text="✏️  Editează baza de date (Excel)",
            font=FONT_BTN, bg="#F0FDF4", fg=CULORI["primar"],
            activebackground="#D1FAE5", relief="flat", cursor="hand2",
            padx=16, pady=6, bd=1, highlightthickness=1,
            highlightbackground=CULORI["primar"],
            command=self._deschide_excel
        )
        btn_ex.pack(side="left")
        btn_ex.bind("<Enter>", lambda e: btn_ex.config(bg="#D1FAE5"))
        btn_ex.bind("<Leave>", lambda e: btn_ex.config(bg="#F0FDF4"))
        tk.Label(rand2,
            text="  ← modifică medicația, date beneficiari sau configurarea centrului",
            font=FONT_MIC, bg=CULORI["card"], fg=CULORI["text_sec"]).pack(side="left")

        self.lbl_avertisment = tk.Label(card, text="", font=FONT_MIC,
                                         bg=CULORI["card"], fg=CULORI["eroare"])
        self.lbl_avertisment.pack(anchor="w", pady=(4, 0))

    def _construieste_tabs(self, parinte):
        """Construiește tab-urile pentru fiecare generator."""
        # Frame container pentru tab-uri custom
        tab_container = tk.Frame(parinte, bg=CULORI["fundal"])
        tab_container.pack(fill="both", expand=True)

        # Bara de tab-uri
        bara_tabs = tk.Frame(tab_container, bg=CULORI["fundal"])
        bara_tabs.pack(fill="x")

        # Frame conținut tab-uri
        self.frame_continut = tk.Frame(tab_container, bg=CULORI["fundal"])
        self.frame_continut.pack(fill="both", expand=True)

        self.tab_buttons  = []
        self.tab_panouri  = []
        self.tab_activ    = tk.IntVar(value=0)

        for i, gen in enumerate(GENERATOARE):
            btn = tk.Button(
                bara_tabs,
                text=f"{gen['icon']} {gen['titlu']}",
                font=("Segoe UI", 9, "bold"),
                relief="flat",
                cursor="hand2",
                padx=10,
                pady=7,
                command=lambda idx=i: self._schimba_tab(idx)
            )
            btn.pack(side="left", padx=(0, 2))
            self.tab_buttons.append(btn)

            # Panou generator
            panou = PanouGenerator(self.frame_continut, self, gen)
            self.tab_panouri.append(panou)

        self._schimba_tab(0)

    def _schimba_tab(self, idx):
        self.tab_activ.set(idx)
        for i, (btn, panou) in enumerate(zip(self.tab_buttons, self.tab_panouri)):
            if i == idx:
                btn.config(bg=CULORI["primar"], fg="white")
                panou.pack(fill="both", expand=True)
            else:
                btn.config(bg=CULORI["tab_inactiv"], fg=CULORI["text"])
                panou.pack_forget()

    def _sectiune_log(self, parinte):
        card = Card(parinte, padx=16, pady=12)
        card.pack(fill="both", expand=True)

        rand = tk.Frame(card, bg=CULORI["card"])
        rand.pack(fill="x", pady=(0, 6))
        tk.Label(rand, text="📋  Jurnal activitate", font=FONT_LABEL,
                 bg=CULORI["card"], fg=CULORI["text"]).pack(side="left")
        BtnSecundar(rand, text="Șterge", command=self._sterge_log,
                    pady=2, padx=8).pack(side="right")

        frame_log = tk.Frame(card, bg=CULORI["card"])
        frame_log.pack(fill="both", expand=True)

        self.txt_log = tk.Text(frame_log, font=("Consolas", 9),
                                bg="#F8F9FA", fg=CULORI["text"],
                                relief="flat", bd=0, state="disabled",
                                wrap="word", height=7)
        scroll = ttk.Scrollbar(frame_log, orient="vertical",
                                command=self.txt_log.yview)
        self.txt_log.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.txt_log.pack(side="left", fill="both", expand=True)

        self.txt_log.tag_config("ok",     foreground=CULORI["succes"])
        self.txt_log.tag_config("eroare", foreground=CULORI["eroare"])
        self.txt_log.tag_config("info",   foreground=CULORI["text_sec"])
        self.txt_log.tag_config("titlu",  foreground=CULORI["primar"],
                                 font=("Consolas", 9, "bold"))

    # ── Logică ──
    def log(self, mesaj, tag="info"):
        """Metodă publică — accesibilă din PanouGenerator."""
        self.txt_log.config(state="normal")
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        self.txt_log.insert("end", f"[{ts}] {mesaj}\n", tag)
        self.txt_log.see("end")
        self.txt_log.config(state="disabled")

    def _sterge_log(self):
        self.txt_log.config(state="normal")
        self.txt_log.delete("1.0", "end")
        self.txt_log.config(state="disabled")

    def _alege_excel(self):
        p = filedialog.askopenfilename(
            title="Selectează baza de date Excel",
            filetypes=[("Excel", "*.xlsx *.xlsm"), ("Toate", "*.*")]
        )
        if p:
            self.excel_var.set(p)
            self._excel_nume = Path(p).name
            self.lbl_excel_nume.config(text=Path(p).name)
            self._verifica_fisiere()

    def _deschide_excel(self):
        excel = self._get_excel_path()
        if not excel.exists():
            messagebox.showerror("Fișier negăsit",
                f"Nu găsesc fișierul Excel:\n{excel.name}\n\n"
                "Folosește butonul 'Alege...' pentru a-l localiza.")
            return
        try:
            os.startfile(str(excel))
            self.log(f"✓ Deschis pentru editare: {excel.name}", "ok")
            self.log("  ⚠ Salvează și închide Excel înainte de a genera fișele.", "info")
        except Exception as ex:
            messagebox.showerror("Eroare", f"Nu am putut deschide Excel:\n{ex}")

    def _verifica_fisiere(self):
        excel   = self._get_excel_path()
        mesaje  = []
        if not excel.exists():
            mesaje.append(
                f"⚠ Nu găsesc baza de date. "
                f"Pune fișierul '{excel.name}' în același folder cu aplicația, "
                f"sau folosește butonul 'Alege...' pentru a-l localiza."
            )
        for gen in GENERATOARE:
            script = cale_relativa(gen["script"])
            if not script.exists():
                mesaje.append(f"⚠ Script lipsă: {gen['script']}")
        if mesaje:
            self.lbl_avertisment.config(text=mesaje[0], fg=CULORI["eroare"])
        else:
            self.lbl_avertisment.config(
                text=f"✓ Bază de date găsită  •  {len(GENERATOARE)} generatoare disponibile",
                fg=CULORI["succes"])


# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────
if __name__ == "__main__":
    app = AppCORE()
    app.mainloop()
