# CORE v3.0 — o inițiativă SocialHub©

Sistem de generare automată a documentației obligatorii pentru centre rezidențiale.

## Fișiere incluse

| Fișier | Descriere |
|--------|-----------|
| CORE_GUI.py | Interfața grafică principală |
| genereaza_fise_sprijin_continuu.py | Generator Fișe Sprijin Continuu (ORD 82) |
| genereaza_fise_sanatate.py | Generator Fișe Monitorizare Sănătate |
| genereaza_fise_monitorizare_lunara.py | Generator Fișe Monitorizare Lunară |
| genereaza_condica_medicamente.py | Generator Condică Medicamente |
| core_termeni.py | Modul Termeni și Condiții |
| core_update.py | Modul Actualizare Online |

## Instalare

1. Instalează Python de la python.org (bifează "Add Python to PATH")
2. Rulează `INSTALEAZA.bat`
3. Lansează cu `Lanseaza_CORE.bat`

## Control activare

Activarea se controlează prin `status.json` din repository-ul `core-updates`.

© 2026 SocialHub© — Uz intern exclusiv
