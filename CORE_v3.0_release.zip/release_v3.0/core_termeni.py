"""
CORE — Modul Termeni și Condiții
Afișează fereastra T&C la prima rulare și salvează acordul.
"""

import tkinter as tk
from tkinter import ttk
import json, datetime, hashlib
from pathlib import Path

CONFIG_FILE = Path(__file__).resolve().parent / ".core_config.json"

TERMENI_TEXT = """TERMENI ȘI CONDIȚII DE UTILIZARE — CORE v3.0
o inițiativă SocialHub©

1. PROPRIETATE ȘI LICENȚĂ
Această aplicație (CORE) este proprietatea exclusivă a inițiativei SocialHub©.
Utilizarea este permisă exclusiv instituțiilor autorizate, în scop intern, 
pentru gestionarea documentației beneficiarilor de servicii sociale.
Distribuirea, copierea sau utilizarea comercială fără acord scris este interzisă.

2. SCOPUL APLICAȚIEI
CORE automatizează generarea documentelor obligatorii conform legislației române 
în vigoare (Ordinul nr. 82/2019, actualizat prin Ordinul 3222/2024, Legea 292/2011,
Legea 448/2006). Aplicația este un instrument de asistență — nu înlocuiește 
responsabilitatea profesională a echipei multidisciplinare.

3. EDITABILITATEA DOCUMENTELOR GENERATE
Documentele produse de această aplicație sunt generate cu valori implicite 
pre-completate pe baza datelor introduse în baza de date. 
UTILIZATORUL ARE OBLIGAȚIA să verifice, corecteze și valideze conținutul 
fiecărui document înainte de semnare și arhivare.
Prin semnarea documentelor generate, utilizatorul își asumă integral 
responsabilitatea pentru veridicitatea și corectitudinea înscrisurilor.

4. PROTECȚIA DATELOR
Toate datele beneficiarilor sunt procesate exclusiv local, pe calculatorul 
instituției. Aplicația nu transmite date cu caracter personal către servere externe.
Utilizatorul este responsabil pentru securitatea accesului la aplicație și 
la baza de date Excel, în conformitate cu GDPR și legislația națională aplicabilă.

5. ACTUALIZĂRI ȘI CONTINUITATE
Aplicația poate fi actualizată periodic pentru a reflecta modificările legislative.
Utilizarea unei versiuni neactualizate după expirarea perioadei de valabilitate 
poate genera documente neconforme cu legislația în vigoare.
Aplicația va fi înlocuită de platforma web SocialHub — la momentul tranziției,
datele din baza de date Excel pot fi importate automat în noua platformă.

6. LIMITAREA RĂSPUNDERII
SocialHub© nu răspunde pentru consecințele utilizării incorecte a aplicației,
pentru erori provenite din date introduse greșit în baza de date, sau pentru
nerespectarea obligației de verificare a documentelor generate.

Prin bifarea acordului și apăsarea butonului „Accept și continuă", 
confirmați că ați citit, înțeles și acceptat în totalitate acești termeni."""

CULORI = {
    "verde":   "#1A6B3C",
    "verde_h": "#145530",
    "fundal":  "#F5F7FA",
    "card":    "#FFFFFF",
    "border":  "#E5E7EB",
    "text":    "#1C1C1E",
    "text_sec":"#6B7280",
    "eroare":  "#DC2626",
}

def este_acceptat():
    """Verifică dacă T&C au fost acceptate."""
    if not CONFIG_FILE.exists():
        return False
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("termeni_acceptati", False)
    except Exception:
        return False

def salveaza_acord(nume_utilizator=""):
    """Salvează acordul cu timestamp."""
    data = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            pass
    data["termeni_acceptati"] = True
    data["data_acceptare"] = datetime.datetime.now().isoformat()
    data["utilizator"] = nume_utilizator
    data["versiune_termeni"] = "3.0"
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

class FerTermeni(tk.Toplevel):
    def __init__(self, parent, callback_accept):
        super().__init__(parent)
        self.callback_accept = callback_accept
        self.acceptat = False

        self.title("CORE v3.0 — Termeni și Condiții de Utilizare")
        self.geometry("700x620")
        self.minsize(600, 500)
        self.configure(bg=CULORI["fundal"])
        self.resizable(True, True)
        self.grab_set()  # Modal
        self.protocol("WM_DELETE_WINDOW", self._refuza)

        # Centrare
        self.update_idletasks()
        px = parent.winfo_x() + (parent.winfo_width()  - 700) // 2
        py = parent.winfo_y() + (parent.winfo_height() - 620) // 2
        self.geometry(f"700x620+{px}+{py}")

        self._construieste()

    def _construieste(self):
        # Header
        hdr = tk.Frame(self, bg=CULORI["verde"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="⚕  CORE — Termeni și Condiții de Utilizare",
                 font=("Segoe UI", 13, "bold"),
                 bg=CULORI["verde"], fg="white").pack(padx=20, pady=12)

        # Subtitlu
        tk.Label(self,
                 text="Citiți cu atenție înainte de a utiliza aplicația.",
                 font=("Segoe UI", 10), bg=CULORI["fundal"],
                 fg=CULORI["text_sec"]).pack(pady=(10, 4))

        # Text termeni
        frame_text = tk.Frame(self, bg=CULORI["card"],
                               highlightthickness=1,
                               highlightbackground=CULORI["border"])
        frame_text.pack(fill="both", expand=True, padx=20, pady=(0, 8))

        scroll = ttk.Scrollbar(frame_text)
        scroll.pack(side="right", fill="y")

        txt = tk.Text(frame_text, font=("Segoe UI", 9),
                      bg=CULORI["card"], fg=CULORI["text"],
                      relief="flat", bd=0, wrap="word",
                      yscrollcommand=scroll.set,
                      state="normal", padx=12, pady=10)
        txt.insert("1.0", TERMENI_TEXT)
        txt.config(state="disabled")
        txt.pack(side="left", fill="both", expand=True)
        scroll.config(command=txt.yview)

        # Zona acord
        frame_acord = tk.Frame(self, bg=CULORI["fundal"])
        frame_acord.pack(fill="x", padx=20, pady=(0, 8))

        self.var_acord = tk.BooleanVar(value=False)
        chk = tk.Checkbutton(
            frame_acord,
            text="Am citit, am înțeles și accept în totalitate Termenii și Condițiile de mai sus.",
            variable=self.var_acord,
            font=("Segoe UI", 10, "bold"),
            bg=CULORI["fundal"], fg=CULORI["text"],
            activebackground=CULORI["fundal"],
            cursor="hand2",
            command=self._toggle_btn
        )
        chk.pack(anchor="w")

        # Nume utilizator
        frame_nume = tk.Frame(self, bg=CULORI["fundal"])
        frame_nume.pack(fill="x", padx=20, pady=(0, 12))
        tk.Label(frame_nume, text="Numele utilizatorului (opțional):",
                 font=("Segoe UI", 9), bg=CULORI["fundal"],
                 fg=CULORI["text_sec"]).pack(side="left")
        self.entry_nume = tk.Entry(frame_nume, font=("Segoe UI", 10),
                                    width=30, relief="flat", bd=1,
                                    highlightthickness=1,
                                    highlightbackground=CULORI["border"])
        self.entry_nume.pack(side="left", padx=(8, 0), ipady=4)

        # Butoane
        frame_btn = tk.Frame(self, bg=CULORI["fundal"])
        frame_btn.pack(fill="x", padx=20, pady=(0, 16))

        self.btn_accept = tk.Button(
            frame_btn,
            text="✓  Accept și continuă",
            font=("Segoe UI", 11, "bold"),
            bg=CULORI["border"], fg=CULORI["text_sec"],
            relief="flat", cursor="hand2", padx=20, pady=10,
            state="disabled",
            command=self._accepta
        )
        self.btn_accept.pack(side="left")

        tk.Button(
            frame_btn,
            text="✕  Refuz — închide aplicația",
            font=("Segoe UI", 10),
            bg=CULORI["fundal"], fg=CULORI["eroare"],
            relief="flat", cursor="hand2", padx=16, pady=10,
            command=self._refuza
        ).pack(side="right")

    def _toggle_btn(self):
        if self.var_acord.get():
            self.btn_accept.config(
                state="normal",
                bg=CULORI["verde"], fg="white",
                activebackground=CULORI["verde_h"]
            )
            self.btn_accept.bind("<Enter>",
                lambda e: self.btn_accept.config(bg=CULORI["verde_h"]))
            self.btn_accept.bind("<Leave>",
                lambda e: self.btn_accept.config(bg=CULORI["verde"]))
        else:
            self.btn_accept.config(
                state="disabled",
                bg=CULORI["border"], fg=CULORI["text_sec"]
            )

    def _accepta(self):
        if not self.var_acord.get():
            return
        nume = self.entry_nume.get().strip()
        salveaza_acord(nume)
        self.acceptat = True
        self.destroy()
        self.callback_accept()

    def _refuza(self):
        self.destroy()
        # Închide aplicația dacă refuză
        try:
            self.master.destroy()
        except Exception:
            pass
