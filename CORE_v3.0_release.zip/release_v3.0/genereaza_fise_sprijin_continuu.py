from openpyxl import load_workbook
from docx import Document
from docx.shared import Cm, Mm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import calendar
import datetime, random, re
from pathlib import Path

# ============================================================
# CORE 2 – Generator fișe sprijin continuu (ORD 82) – V1.4.1 (curat)
# Fixuri majore față de V1:
# - citește PROGRAM_ZILNIC (include micul dejun 08:00–08:30 etc.)
# - folosește ACTIVITATI + BIBLIOTECA_TEXTE (structura reală din Excel)
# - evită "sărbătorirea..." generică: o filtrează dacă NU e eveniment
# - reduce încărcarea: injectează EVALUARE_FUNCTIONALA doar în intervale-cheie:
#     * dimineata: igienă
#     * masa: hrănire
#     * dupa_amiaza (intervalul tardiv, ex. 16:00–19:00): mobilitate + comunicare
# ============================================================

EXCEL = "Master_CORE_v2_CORECTAT.xlsx"
OUTPUT = None  # se calculează dinamic în main()

# -------------------------
# Reglaje: aerisire injecții funcționale + texte de context
INJECT_HRANIRE_ONCE_PER_DAY = True   # True = doar o masă/zi primește text funcțional hrănire
INJECT_HRANIRE_PREFER = "pranz"      # "mic_dejun" / "pranz" / "cina"
INJECT_MOB_COM_EVERY_N_DAYS = 2      # 1 = zilnic, 2 = o dată la 2 zile, 3 = o dată la 3 zile
INJECT_IGIENA_EVERY_N_DAYS = 1       # 1 = zilnic, 2 = o dată la 2 zile

# Texte de context (din BIBLIOTECA_TEXTE): CTX_MASA / CTX_ZI
# - apar rar, fără declanșare medicală
CTX_MASA_PROB = 0.22                # probabilitate pe masă (se mai filtrează de zi/masa)
CTX_ZI_PROB = 0.18                  # probabilitate la final de zi

# -------------------------
# Utils: date / normalizare
# -------------------------
def fmt_date(v):
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return None
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except Exception:
            pass
    try:
        return datetime.date.fromisoformat(s.split()[0])
    except Exception:
        return None

def parse_time(v):
    if isinstance(v, datetime.time):
        return v
    if isinstance(v, datetime.datetime):
        return v.time()
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return None
    # acceptă "08:00"
    try:
        hh, mm = s.split(":")[:2]
        return datetime.time(int(hh), int(mm))
    except Exception:
        return None

def time_to_str(t):
    return "" if t is None else f"{t.hour:02d}:{t.minute:02d}"

def calc_age(birth_date, year, month, day):
    if birth_date is None:
        return None
    years = year - birth_date.year
    if (month, day) < (birth_date.month, birth_date.day):
        years -= 1
    return years

def norm_key(s):
    import unicodedata, re as _re
    s = str(s).strip().lower()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    s = _re.sub(r'\s+', ' ', s)
    return s

def get_headers(ws):
    headers = {}
    row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
    for idx, v in enumerate(row):
        if v is None:
            continue
        headers[norm_key(v)] = idx
    return headers

def find_col(headers, *needles):
    for n in needles:
        nk = norm_key(n)
        if nk in headers:
            return headers[nk]
    for k, idx in headers.items():
        for n in needles:
            nn = norm_key(n)
            if nn and nn in k:
                return idx
    return None

def get_sheet_ci(wb, *names):
    lower_map = {s.lower(): s for s in wb.sheetnames}
    for n in names:
        if n.lower() in lower_map:
            return wb[lower_map[n.lower()]]
    return None

def resolve_excel_path(default_name):
    # Caută întotdeauna relativ la folderul scriptului
    script_dir = Path(__file__).resolve().parent
    p = script_dir / default_name
    if p.exists():
        return p
    # Fallback: orice xlsx în același folder
    candidates = sorted(script_dir.glob("*.xlsx"))
    if candidates:
        print(f"Notă: nu găsesc '{default_name}'. Folosesc: {candidates[0].name}")
        return candidates[0]
    name = input("Nu găsesc fișierul Excel. Introdu numele fișierului (.xlsx): ").strip()
    return script_dir / name

# -------------------------
# DOCX formatting helpers
# -------------------------
def set_table_outer_and_vertical_borders(table, sz="10"):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = tblPr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tblPr.append(borders)
    def set_edge(edge, val):
        el = borders.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            borders.append(el)
        el.set(qn("w:val"), val)
        el.set(qn("w:sz"), sz)
        el.set(qn("w:color"), "000000")
        el.set(qn("w:space"), "0")
    for e in ("top","left","bottom","right"):
        set_edge(e, "single")
    set_edge("insideV","single")
    set_edge("insideH","nil")

def set_cell_bottom_border(cell, val="single", sz="10"):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.find(qn("w:tcBorders"))
    if tcBorders is None:
        tcBorders = OxmlElement("w:tcBorders")
        tcPr.append(tcBorders)
    bottom = tcBorders.find(qn("w:bottom"))
    if bottom is None:
        bottom = OxmlElement("w:bottom")
        tcBorders.append(bottom)
    bottom.set(qn("w:val"), val)
    bottom.set(qn("w:sz"), sz)
    bottom.set(qn("w:color"), "000000")
    bottom.set(qn("w:space"), "0")

def set_cell_margins(cell, top=110, start=70, bottom=110, end=70):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.find(qn('w:tcMar'))
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in (('top', top), ('start', start), ('bottom', bottom), ('end', end)):
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')

def add_odd_page_section(doc):
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    try:
        section.header.is_linked_to_previous = True
        section.footer.is_linked_to_previous = True
    except Exception:
        pass
    sectPr = section._sectPr
    type_el = sectPr.find(qn('w:type'))
    if type_el is None:
        type_el = OxmlElement('w:type')
        sectPr.insert(0, type_el)
    type_el.set(qn('w:val'), 'oddPage')
    return section


def add_page_field(paragraph):
    """Inserează câmpul PAGE într-un paragraf (pentru număr de pagină)."""
    run = paragraph.add_run()
    fldBegin = OxmlElement('w:fldChar')
    fldBegin.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = ' PAGE '
    fldSeparate = OxmlElement('w:fldChar')
    fldSeparate.set(qn('w:fldCharType'), 'separate')
    fldEnd = OxmlElement('w:fldChar')
    fldEnd.set(qn('w:fldCharType'), 'end')
    run._r.append(fldBegin)
    run._r.append(instrText)
    run._r.append(fldSeparate)
    run._r.append(fldEnd)
    return paragraph

# -------------------------
# STATUT_BENEFICIAR (override pe zile)
# -------------------------
def load_status_sheet(wb):
    ws = get_sheet_ci(wb, "STATUT_BENEFICIAR")
    if ws is None:
        return {}
    headers = get_headers(ws)
    c_id = find_col(headers, "id_beneficiar", "id")
    c_tip = find_col(headers, "tip_statut", "statut")
    c_start = find_col(headers, "data_start", "start")
    c_end = find_col(headers, "data_end", "end")
    c_obs = find_col(headers, "observatii", "obs")
    if c_id is None or c_tip is None or c_start is None:
        return {}
    out = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or all(v is None or str(v).strip()=="" for v in row):
            continue
        bid = row[c_id] if c_id < len(row) else None
        tip = row[c_tip] if c_tip < len(row) else None
        ds = row[c_start] if c_start < len(row) else None
        de = row[c_end] if (c_end is not None and c_end < len(row)) else None
        obs = row[c_obs] if (c_obs is not None and c_obs < len(row)) else None
        if not bid or not tip:
            continue
        start = fmt_date(ds)
        if start is None:
            continue
        end = fmt_date(de) if de else start
        out.setdefault(str(bid).strip(), []).append({
            "start": start, "end": end,
            "tip": str(tip).strip().upper(),
            "obs": "" if obs is None else str(obs).strip()
        })
    return out

def status_priority(tip):
    t = (tip or "").upper()
    if "DECES" in t or "INACTIV" in t:
        return 100
    if "INTERNAT" in t or "SPITAL" in t:
        return 80
    if "INVOIRE" in t or "VIZITA" in t or "FAMIL" in t:
        return 60
    if "VACAN" in t or "PLECAT" in t or "ABSENT" in t or "TRANSFER" in t:
        return 50
    return 40

def status_text(tip, obs=""):
    t = (tip or "").upper()
    base = "Beneficiarul a avut statut special (indisponibil pentru rutina centrului) în această zi."
    if "DECES" in t:
        base = "Beneficiarul este decedat."
    elif "INACTIV" in t:
        base = "Beneficiarul este inactiv (nu se află în evidența centrului) în această perioadă."
    elif "INTERNAT" in t or "SPITAL" in t:
        base = "Beneficiarul a fost internat în unitate spitalicească, unde a beneficiat de îngrijiri medicale de specialitate."
    elif "INVOIRE" in t or "VIZITA" in t or "FAMIL" in t:
        base = "Beneficiarul a fost învoit / plecat în vizită la familie."
    elif "VACAN" in t:
        base = "Beneficiarul a fost în perioada de vacanță (plecat temporar din centru)."
    elif "TRANSFER" in t:
        base = "Beneficiarul a fost transferat temporar."
    elif "ABSENT" in t:
        base = "Beneficiarul a fost absent temporar din centru."
    return f"{base} {obs}".strip() if obs else base

def get_status_for_day(status_map, bid, date_obj):
    if not status_map or not bid:
        return None
    recs = status_map.get(bid, [])
    active = [r for r in recs if r["start"] <= date_obj <= r["end"]]
    if not active:
        return None
    active.sort(key=lambda r: status_priority(r["tip"]), reverse=True)
    return active[0]

# -------------------------
# PROGRAM_ZILNIC / ACTIVITATI / BIBLIOTECA_TEXTE
# -------------------------
def season_for_month(month):
    return "VARA" if month in (5,6,7,8,9) else "IARNA"

def load_program_zilnic(wb):
    ws = get_sheet_ci(wb, "PROGRAM_ZILNIC")
    if ws is None:
        raise RuntimeError("Nu găsesc foaia PROGRAM_ZILNIC.")
    headers = get_headers(ws)
    c_id = find_col(headers, "interval_id")
    c_start = find_col(headers, "ora_start")
    c_stop = find_col(headers, "ora_stop")
    c_cod = find_col(headers, "interval_cod")
    c_ord = find_col(headers, "ordine")
    c_obs = find_col(headers, "observatie_standard", "observație_standard", "observatie")
    if None in (c_id, c_start, c_stop, c_cod, c_ord):
        raise RuntimeError("PROGRAM_ZILNIC: lipsesc coloane necesare (interval_id, ora_start, ora_stop, interval_cod, ordine).")
    out = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or all(v is None or str(v).strip()=="" for v in row):
            continue
        iv_id = str(row[c_id]).strip()
        start = parse_time(row[c_start])
        stop = parse_time(row[c_stop])
        cod = "" if row[c_cod] is None else str(row[c_cod]).strip().lower()
        ordine = row[c_ord]
        try:
            ordine = int(ordine)
        except Exception:
            continue
        obs = ""
        if c_obs is not None and c_obs < len(row) and row[c_obs] is not None:
            obs = str(row[c_obs]).strip()
        label = f"{time_to_str(start)} – {time_to_str(stop)}"
        out.append({
            "interval_id": iv_id,
            "start": start,
            "stop": stop,
            "cod": cod,
            "ordine": ordine,
            "obs": obs,
            "label": label,
        })
    out.sort(key=lambda x: x["ordine"])
    return out

def load_activitati(wb):
    ws = get_sheet_ci(wb, "ACTIVITATI")
    if ws is None:
        raise RuntimeError("Nu găsesc foaia ACTIVITATI.")
    headers = get_headers(ws)
    c_id = find_col(headers, "activitate_id")
    c_cod = find_col(headers, "interval_cod")
    c_act = find_col(headers, "activ")
    if None in (c_id, c_cod, c_act):
        raise RuntimeError("ACTIVITATI: lipsesc coloane necesare.")
    by_cod = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row:
            continue
        active = str(row[c_act]).strip().upper() if c_act < len(row) and row[c_act] is not None else "NU"
        if active != "DA":
            continue
        act_id = str(row[c_id]).strip()
        cod = str(row[c_cod]).strip().lower() if c_cod < len(row) and row[c_cod] is not None else "all"
        by_cod.setdefault(cod, []).append(act_id)
    return by_cod

def load_biblioteca(wb):
    ws = get_sheet_ci(wb, "BIBLIOTECA_TEXTE")
    if ws is None:
        return {}
    headers = get_headers(ws)
    c_act = find_col(headers, "activitate_id")
    c_cod = find_col(headers, "interval_cod")
    c_sez = find_col(headers, "sezon")
    c_txt = find_col(headers, "text")
    c_on = find_col(headers, "activ")
    if None in (c_act, c_cod, c_sez, c_txt, c_on):
        return {}

    lib = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row:
            continue
        active = str(row[c_on]).strip().upper() if c_on < len(row) and row[c_on] is not None else "NU"
        if active != "DA":
            continue
        act_id = str(row[c_act]).strip()
        cod = str(row[c_cod]).strip().lower() if c_cod < len(row) and row[c_cod] is not None else "all"
        sez = str(row[c_sez]).strip().upper() if c_sez < len(row) and row[c_sez] is not None else "ALL"
        txt = str(row[c_txt]).strip() if c_txt < len(row) and row[c_txt] is not None else ""
        if not txt:
            continue
        lib.setdefault((act_id, cod, sez), []).append(txt)
    return lib

def pick_activity_text(interval_cod, sezon, activitati_by_cod, lib, rng, allow_celebration=False):
    # select activity id
    candidates = []
    candidates.extend(activitati_by_cod.get(interval_cod, []))
    candidates.extend(activitati_by_cod.get("all", []))
    candidates = list(dict.fromkeys(candidates))  # unique, keep order
    if not candidates:
        return ""
    act_id = rng.choice(candidates)

    # select texts for that activity id and interval_cod (or ALL)
    texts = []
    texts.extend(lib.get((act_id, interval_cod, sezon), []))
    texts.extend(lib.get((act_id, interval_cod, "ALL"), []))
    texts.extend(lib.get((act_id, "all", sezon), []))
    texts.extend(lib.get((act_id, "all", "ALL"), []))

    if not texts:
        return ""

    def is_celebration(s):
        s2 = s.lower()
        return ("sarbator" in s2) or ("sărbător" in s2) or ("onomastic" in s2) or ("ziua de nastere" in s2) or ("ziua de naștere" in s2)

    if not allow_celebration:
        texts = [t for t in texts if not is_celebration(t)]
        if not texts:
            return ""

    return rng.choice(texts)

def meal_label(start_time):
    if not start_time:
        return "mesei"
    hh = start_time.hour + start_time.minute/60.0
    if hh <= 9.5:
        return "micului dejun"
    if hh <= 15.5:
        return "prânzului"
    return "cinei"

# -------------------------
# Bibliotecă texte – EVALUARE_FUNCTIONALA (anti-repetiție)
# Convenție în BIBLIOTECA_TEXTE:
#  - activitate_id:
#       FUNC_COM_V0..V4  (comunicare verbală)
#       FUNC_HRA_V0..V2  (hrănire)
#       FUNC_MOB_V0..V3  (mobilitate)
#       FUNC_IGH_V0..V3  (igienă personală)
#  - interval_cod: "func" (recomandat) sau "all"
#  - sezon: ALL (recomandat) / IARNA / VARA (opțional)
#
# Dacă nu există suficiente texte pentru un nivel, se face fallback pe textul determinist.
# -------------------------

def pick_func_text(lib, rng, kind, level, sezon="ALL", interval_cod="func"):
    if level is None:
        return ""
    try:
        lvl = int(level)
    except Exception:
        return ""
    act_id = f"FUNC_{kind}_V{lvl}"
    texts = []
    texts.extend(lib.get((act_id, interval_cod, sezon), []))
    texts.extend(lib.get((act_id, interval_cod, "ALL"), []))
    texts.extend(lib.get((act_id, "all", sezon), []))
    texts.extend(lib.get((act_id, "all", "ALL"), []))
    return rng.choice(texts) if texts else ""

def pick_or_fallback(lib, rng, kind, level, fallback_text, sezon="ALL"):
    t = pick_func_text(lib, rng, kind, level, sezon=sezon, interval_cod="func")
    return t if t else fallback_text


# -------------------------
# Bibliotecă texte – CONTEXT (footer etc.)
# Convenție în BIBLIOTECA_TEXTE:
#   CTX_FOOTER | interval_cod=ALL | sezon=ALL
# Textul din footer se alege aleator o singură dată per document.
# -------------------------
def pick_ctx_text(lib, rng, ctx_id, interval_cod='ALL', sezon='ALL'):
    texts = []
    texts.extend(lib.get((ctx_id, interval_cod, sezon), []))
    texts.extend(lib.get((ctx_id, interval_cod, 'ALL'), []))
    texts.extend(lib.get((ctx_id, 'all', sezon), []))
    texts.extend(lib.get((ctx_id, 'all', 'ALL'), []))
    return rng.choice(texts) if texts else ''


# -------------------------
# Bibliotecă texte – CONTEXT (anti-repetiție, non-medical)
# Convenție în BIBLIOTECA_TEXTE:
#   CTX_MASA | interval_cod=masa | sezon=ALL
#   CTX_ZI   | interval_cod=ALL  | sezon=ALL
# -------------------------

def pick_ctx_text(lib, rng, ctx_id, interval_cod, sezon="ALL"):
    texts = []
    texts.extend(lib.get((ctx_id, interval_cod, sezon), []))
    texts.extend(lib.get((ctx_id, interval_cod, "ALL"), []))
    texts.extend(lib.get((ctx_id, "all", sezon), []))
    texts.extend(lib.get((ctx_id, "all", "ALL"), []))
    return rng.choice(texts) if texts else ""



# -------------------------
# EVALUARE_FUNCTIONALA (CORE 2)
# -------------------------
def _parse_leading_int(v):
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return None
    if s[0].isdigit():
        return int(s[0])
    for ch in s:
        if ch.isdigit():
            return int(ch)
    return None

def _parse_da_nu(v):
    if v is None:
        return None
    s = str(v).strip().upper()
    if not s:
        return None
    if s in ("DA","D","YES","Y","1","TRUE"):
        return "DA"
    if s in ("NU","N","NO","0","FALSE"):
        return "NU"
    return s

def _parse_text(v):
    return "" if v is None else str(v).strip()

def load_evaluare_functionala(wb):
    ws = get_sheet_ci(wb, "EVALUARE_FUNCTIONALA")
    if ws is None:
        return {}
    headers = get_headers(ws)
    c_id = find_col(headers, "id_beneficiar", "id")
    if c_id is None:
        return {}

    def fc(*names):
        return find_col(headers, *names)

    out = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row:
            continue
        bid = row[c_id] if c_id < len(row) else None
        if not bid or str(bid).strip()=="":
            continue
        bid = str(bid).strip()
        rec = {
            "status_functional": _parse_text(row[fc("status_functional","status functional")]) if fc("status_functional","status functional") is not None else "",
            "mobilitate": _parse_leading_int(row[fc("mobilitate")]) if fc("mobilitate") is not None else None,
            "foloseste_scaun": _parse_da_nu(row[fc("foloseste_scaun","foloseste scaun","scaun")]) if fc("foloseste_scaun","foloseste scaun","scaun") is not None else None,
            "risc_caderi": _parse_da_nu(row[fc("risc_caderi","risc caderi")]) if fc("risc_caderi","risc caderi") is not None else None,
            "igiena_personala": _parse_leading_int(row[fc("igiena_personala","igiena")]) if fc("igiena_personala","igiena") is not None else None,
            "imbracare": _parse_leading_int(row[fc("imbracare","îmbrăcare")]) if fc("imbracare","îmbrăcare") is not None else None,
            "hranire": _parse_leading_int(row[fc("hranire","hrănire")]) if fc("hranire","hrănire") is not None else None,
            "dificultati_deglutitie": _parse_da_nu(row[fc("dificultati_deglutitie","deglutitie")]) if fc("dificultati_deglutitie","deglutitie") is not None else None,
            "dieta_speciala": _parse_text(row[fc("dieta_speciala","dieta")]).lower() if fc("dieta_speciala","dieta") is not None else "",
            "comunicare_verbala": _parse_leading_int(row[fc("comunicare_verbala","comunicare verbala")]) if fc("comunicare_verbala","comunicare verbala") is not None else None,
            "comunicare_nonverbala": _parse_leading_int(row[fc("comunicare_nonverbala","comunicare nonverbala")]) if fc("comunicare_nonverbala","comunicare nonverbala") is not None else None,
            "stil_comunicare": _parse_text(row[fc("stil_comunicare","stil comunicare")]).lower() if fc("stil_comunicare","stil comunicare") is not None else "",
            "observatii_comunicare": _parse_text(row[fc("observatii_comunicare","observatii comunicare","observații comunicare")]) if fc("observatii_comunicare","observatii comunicare","observații comunicare") is not None else "",
            "cooperare": _parse_leading_int(row[fc("cooperare")]) if fc("cooperare") is not None else None,
            "nivel_supraveghere": _parse_leading_int(row[fc("nivel_supraveghere","supraveghere")]) if fc("nivel_supraveghere","supraveghere") is not None else None,
        }
        out[bid] = rec
    return out

def _is_inactiv(val):
    return (val or "").strip().upper() == "INACTIV"

# -------------------------
# Text helpers: EVALUARE -> propoziții
# -------------------------
def ensure_dot(s):
    s = (s or "").strip()
    if not s:
        return ""
    if s[-1] not in ".!?":
        return s + "."
    return s

def join_sentences(*parts):
    clean = []
    for p in parts:
        s = (p or "").strip()
        if s:
            clean.append(s)
    return " ".join(clean).strip()

def text_comunicare(e, rng):
    if not e:
        return ""
    v = e.get("comunicare_verbala")
    nv = e.get("comunicare_nonverbala")
    stil = (e.get("stil_comunicare") or "").strip().lower()
    obs = (e.get("observatii_comunicare") or "").strip()
    coop = e.get("cooperare")

    base = ""
    if v is None:
        return ""
    if v == 0:
        if nv == 2:
            base = rng.choice([
                "Beneficiarul nu comunică verbal, însă comunică nonverbal eficient prin gesturi, mimică și reacții la stimuli",
                "Beneficiarul nu verbalizează, dar comunică nonverbal adecvat prin gesturi și expresii faciale",
            ])
        elif nv == 1:
            base = rng.choice([
                "Beneficiarul nu comunică verbal, dar răspunde ocazional prin gesturi sau expresii faciale simple",
                "Beneficiarul nu verbalizează, însă prezintă răspunsuri nonverbale ocazionale (gesturi/mimică)",
            ])
        else:
            base = rng.choice([
                "Beneficiarul nu comunică verbal, comunicarea realizându-se preponderent prin reacții nonverbale discrete",
                "Beneficiarul nu verbalizează, manifestând reacții minime la stimuli",
            ])
    elif v == 1:
        base = rng.choice([
            "Beneficiarul nu utilizează limbaj verbal structurat, dar vocalizează în contexte funcționale, exprimându-și nevoile prin sunete și reacții nonverbale",
            "Beneficiarul nu folosește limbaj verbal structurat; vocalizează și reacționează nonverbal în contexte funcționale",
        ])
    elif v == 2:
        if stil in ("limbaj propriu","mixt","ecolalie"):
            base = rng.choice([
                "Beneficiarul utilizează cuvinte izolate și expresii proprii, comunicarea fiind înțeleasă în principal de personalul care îl cunoaște",
                "Beneficiarul comunică prin cuvinte izolate și expresii specifice, interpretate de personalul care îl cunoaște",
            ])
        else:
            base = rng.choice([
                "Beneficiarul utilizează cuvinte izolate pentru a comunica nevoi sau reacții simple",
                "Beneficiarul comunică prin cuvinte izolate, transmițând nevoi de bază și reacții simple",
            ])
    elif v == 3:
        base = rng.choice([
            "Beneficiarul comunică verbal prin cuvinte și fraze scurte, reușind să transmită informații simple în contexte familiare",
            "Beneficiarul comunică verbal prin fraze scurte, în contexte familiare, cu sprijin la nevoie",
        ])
    elif v == 4:
        base = rng.choice([
            "Beneficiarul comunică verbal coerent, participând la interacțiuni și conversații adaptate contextului",
            "Beneficiarul comunică verbal adecvat, participând la conversații și interacțiuni în cadrul grupului",
        ])

    extra_stil = ""
    if stil == "limbaj propriu":
        extra_stil = "Comunicarea se realizează preponderent printr-un limbaj propriu, la care personalul se adaptează"
    elif stil == "ecolalie":
        extra_stil = "Comunicarea este marcată de ecolalie, cu repetarea unor cuvinte sau expresii"
    elif stil == "mixt":
        extra_stil = "Comunicarea este mixtă, combinând cuvinte uzuale cu expresii proprii"

    extra_obs = f"Observații: {obs}" if obs else ""

    extra_coop = ""
    if coop == 0:
        extra_coop = "Gradul de implicare în interacțiune este uneori limitat de refuzul cooperării"
    elif coop == 1:
        extra_coop = "Gradul de implicare este variabil, în funcție de context și dispoziție"

    return join_sentences(ensure_dot(base), ensure_dot(extra_stil), ensure_dot(extra_obs), ensure_dot(extra_coop))

def text_hranire(e, rng):
    if not e:
        return ""
    hr = e.get("hranire")
    deg = (e.get("dificultati_deglutitie") or "").upper()
    dieta = (e.get("dieta_speciala") or "").strip().lower()
    coop = e.get("cooperare")
    if hr is None:
        return ""
    if hr == 0:
        base = rng.choice([
            "Beneficiarul este hrănit de personal, necesitând sprijin integral în timpul servirii meselor",
            "Beneficiarul necesită sprijin integral la alimentație, fiind hrănit de personal",
        ])
    elif hr == 1:
        base = rng.choice([
            "Beneficiarul necesită asistență la servirea meselor, fiind sprijinit pentru menținerea unui ritm adecvat de alimentație",
            "Beneficiarul este asistat la servirea meselor, cu sprijin pentru un ritm adecvat de alimentație",
        ])
    else:
        base = rng.choice([
            "Beneficiarul se alimentează independent, cu supraveghere și sprijin minim din partea personalului, după caz",
            "Beneficiarul se alimentează independent, fiind supravegheat și sprijinit minimal, după caz",
        ])
    extra_deg = "Alimentația se realizează cu atenție sporită, având în vedere dificultățile de deglutiție" if deg == "DA" else ""
    extra_dieta = ""
    if dieta and dieta != "nu":
        if dieta == "pasata":
            extra_dieta = "Beneficiarul urmează o dietă pasată, adaptată nevoilor sale"
        elif dieta == "hipocalorica":
            extra_dieta = "Beneficiarul urmează o dietă hipocalorică, conform recomandărilor"
        else:
            extra_dieta = "Beneficiarul urmează o dietă adaptată, conform indicațiilor medicale"
    extra_coop = ""
    if coop == 0:
        extra_coop = "Servirea meselor este uneori îngreunată de refuzul alimentar"
    elif coop == 1:
        extra_coop = "Acceptarea alimentației este variabilă, în funcție de dispoziția beneficiarului"
    return join_sentences(ensure_dot(base), ensure_dot(extra_deg), ensure_dot(extra_dieta), ensure_dot(extra_coop))

def text_mobilitate(e, rng):
    if not e:
        return ""
    mob = e.get("mobilitate")
    scaun = (e.get("foloseste_scaun") or "").upper()
    risc = (e.get("risc_caderi") or "").upper()
    supr = e.get("nivel_supraveghere")
    coop = e.get("cooperare")
    if mob is None:
        return ""
    if mob == 0:
        base = rng.choice([
            "Beneficiarul este imobilizat, necesitând mobilizare pasivă cu sprijinul personalului",
            "Beneficiarul prezintă mobilitate sever limitată, necesitând mobilizare pasivă cu sprijinul personalului",
        ])
    elif mob == 1:
        base = rng.choice([
            "Beneficiarul realizează transferuri cu sprijin din partea personalului, fiind necesară asistare constantă",
            "Beneficiarul efectuează transferuri cu sprijin, necesitând asistare constantă din partea personalului",
        ])
    elif mob == 2:
        base = rng.choice([
            "Beneficiarul se deplasează cu sprijinul personalului, necesitând asistare pentru menținerea siguranței",
            "Beneficiarul se deplasează asistat, cu sprijin pentru siguranță și orientare",
        ])
    else:
        base = rng.choice([
            "Beneficiarul se deplasează independent în spațiile centrului",
            "Beneficiarul se deplasează independent în cadrul centrului",
        ])
    extra_scaun = "Pentru deplasare, beneficiarul utilizează scaun rulant, cu sprijinul personalului" if scaun == "DA" else ""
    extra_risc = "Există risc de căderi, motiv pentru care este necesară supraveghere sporită în timpul deplasării" if risc == "DA" else ""
    extra_supr = ""
    if supr == 0:
        extra_supr = "Beneficiarul necesită supraveghere permanentă în timpul mobilizării"
    elif supr == 1:
        extra_supr = "Beneficiarul este monitorizat periodic în timpul deplasării"
    elif supr == 2:
        extra_supr = "Beneficiarul necesită supraveghere minimă în timpul deplasării"
    extra_coop = ""
    if coop == 0:
        extra_coop = "Mobilizarea este uneori îngreunată de refuzul cooperării"
    elif coop == 1:
        extra_coop = "Nivelul de cooperare este variabil, în funcție de context și dispoziție"
    return join_sentences(ensure_dot(base), ensure_dot(extra_scaun), ensure_dot(extra_risc), ensure_dot(extra_supr), ensure_dot(extra_coop))

def text_igiena(e, rng):
    if not e:
        return ""
    ig = e.get("igiena_personala")
    im = e.get("imbracare")
    coop = e.get("cooperare")
    if ig is None and im is None:
        return ""
    base = ""
    if ig == 0:
        base = "Beneficiarul necesită sprijin integral din partea personalului pentru realizarea activităților de igienă personală"
    elif ig == 1:
        base = "Beneficiarul realizează activitățile de igienă personală cu sprijin parțial din partea personalului"
    elif ig == 2:
        base = "Beneficiarul realizează activitățile de igienă personală sub supravegherea personalului"
    elif ig == 3:
        base = "Beneficiarul realizează independent activitățile de igienă personală"
    extra_im = ""
    if im == 0:
        extra_im = "Îmbrăcarea și dezbrăcarea se realizează cu sprijinul personalului"
    elif im == 1:
        extra_im = "Îmbrăcarea și dezbrăcarea se realizează cu sprijin parțial"
    elif im == 2:
        extra_im = "Îmbrăcarea și dezbrăcarea se realizează independent"
    extra_coop = ""
    if coop == 0:
        extra_coop = "Realizarea activităților de igienă este uneori îngreunată de refuzul beneficiarului"
    elif coop == 1:
        extra_coop = "Gradul de cooperare în realizarea activităților de igienă este variabil"
    return join_sentences(ensure_dot(base), ensure_dot(extra_im), ensure_dot(extra_coop))

# -------------------------
# Evenimente (zi naștere / onomastică)
# -------------------------
EVENT_TEXTS = {
    "bday_celebrant": [
        "În cadrul activităților de grup a fost sărbătorită ziua de naștere a beneficiarului, care a împlinit {age} ani, prin activități recreative și de socializare.",
        "Cu ocazia împlinirii vârstei de {age} ani, beneficiarul a participat la activități de grup (muzică, jocuri, socializare), manifestând interes și bună dispoziție.",
    ],
    "bday_others": [
        "Beneficiarul a participat la sărbătorirea zilei de naștere a unui membru al grupului, prin activități recreative și de socializare.",
        "În cadrul activităților de grup a fost marcată ziua de naștere a unui beneficiar, cu participarea membrilor grupului.",
    ],
    "nameday_target": [
        "În cadrul activităților de grup a fost marcată onomastica beneficiarului, prin activități recreative și de socializare.",
        "A fost sărbătorită onomastica beneficiarului, prin activități de grup (muzică, jocuri, socializare), într-un climat pozitiv.",
    ],
    "nameday_others": [
        "Beneficiarul a participat la marcarea onomasticii unui membru al grupului, prin activități recreative și de socializare.",
        "În cadrul activităților de grup a fost marcată onomastica unui beneficiar, cu participarea membrilor grupului.",
    ],
}

def adauga_subsol_legal(doc, baza_legala=None):
    """Adaugă baza legală în subsolul documentului — corp 6.5pt, centrat."""
    from docx.shared import Pt, RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    if baza_legala is None:
        baza_legala = (
            "Document generat de CORE v3.0 — o inițiativă SocialHub©  |  "
            "Temei legal: Ord. 82/2019 actualizat prin Ord. 3222/2024 (MMSS)  |  "
            "Legea 292/2011  |  Legea 448/2006  |  "
            "Document editabil — utilizatorul își asumă responsabilitatea "
            "pentru veridicitatea înscrisurilor după semnare și arhivare."
        )
    for section in doc.sections:
        footer = section.footer
        if footer.paragraphs:
            p = footer.paragraphs[0]
            p.clear()
        else:
            p = footer.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after  = Pt(0)
        pPr = p._p.get_or_add_pPr()
        pBdr = OxmlElement("w:pBdr")
        top = OxmlElement("w:top")
        top.set(qn("w:val"), "single"); top.set(qn("w:sz"), "4")
        top.set(qn("w:space"), "1");    top.set(qn("w:color"), "CCCCCC")
        pBdr.append(top); pPr.append(pBdr)
        run = p.add_run(baza_legala)
        run.font.size = Pt(6.5)
        run.font.name = "Times New Roman"
        run.font.color.rgb = RGBColor(0x6B, 0x72, 0x80)


def main():
    luna = int(input("Luna (1-12): ").strip())
    an = int(input("Anul (ex: 2026): ").strip())

    excel_path = resolve_excel_path(EXCEL)
    wb = load_workbook(excel_path, data_only=True)

    ws_benef = get_sheet_ci(wb, "BENEFICIARI", "Beneficiari")
    if ws_benef is None:
        raise RuntimeError("Nu găsesc foaia 'BENEFICIARI' în Excel.")

    # load sources
    program = load_program_zilnic(wb)
    activitati_by_cod = load_activitati(wb)
    lib = load_biblioteca(wb)
    status_map = load_status_sheet(wb)
    eval_map = load_evaluare_functionala(wb)

    # identify event slot: ultimul interval dupa_amiaza din program (după ordine)
    dupa = [p for p in program if p["cod"] == "dupa_amiaza"]
    event_slot_id = dupa[-1]["interval_id"] if dupa else None

    # read beneficiaries
    h = get_headers(ws_benef)
    idx_id = find_col(h, "id_beneficiar", "id")
    idx_nume = find_col(h, "nume")
    idx_pren = find_col(h, "prenume")
    idx_dn = find_col(h, "data_nasterii", "data nasterii", "data nastere")
    idx_status = find_col(h, "status")
    idx_diag1 = find_col(h, "diagnostic_principal")
    idx_diag2 = find_col(h, "diagnostic_secundar")
    idx_grad = find_col(h, "grad_handicap", "grad handicap", "grad")
    idx_onom = find_col(h, "onomastica", "onomastică", "onom")

    benef = []
    for row in ws_benef.iter_rows(min_row=2, values_only=True):
        if not row or all(v is None or str(v).strip()=="" for v in row):
            continue
        status = row[idx_status] if idx_status is not None and idx_status < len(row) else None
        if str(status).strip().lower() != "activ":
            continue
        bid = row[idx_id] if idx_id is not None and idx_id < len(row) else None
        bid = "" if bid is None else str(bid).strip()
        nume = row[idx_nume] if idx_nume is not None and idx_nume < len(row) else ""
        pren = row[idx_pren] if idx_pren is not None and idx_pren < len(row) else ""
        dn = row[idx_dn] if idx_dn is not None and idx_dn < len(row) else None
        diag1 = row[idx_diag1] if idx_diag1 is not None and idx_diag1 < len(row) else None
        diag2 = row[idx_diag2] if idx_diag2 is not None and idx_diag2 < len(row) else None
        grad = row[idx_grad] if idx_grad is not None and idx_grad < len(row) else None
        onom = row[idx_onom] if idx_onom is not None and idx_onom < len(row) else None

        birth = fmt_date(dn)
        onom_d = fmt_date(onom)
        onom_dm = str(onom).strip() if (onom and onom_d is None) else None

        diag = " / ".join([str(x).strip() for x in (diag1, diag2) if x is not None and str(x).strip()!=""])
        benef.append({
            "id": bid,
            "nume_complet": f"{nume} {pren}".strip(),
            "birth": birth,
            "diag": diag,
            "grad": "" if grad is None else str(grad).strip(),
            "onom": onom_d,
            "onom_dm": onom_dm,
        })

    # build bdays / namedays maps for the selected month
    bdays = {}
    namedays = {}
    for i, b in enumerate(benef):
        if b["birth"] and b["birth"].month == luna:
            bdays.setdefault(b["birth"].day, []).append(i)
        if b["onom"] and b["onom"].month == luna:
            namedays.setdefault(b["onom"].day, []).append(i)
        elif b["onom_dm"]:
            s = b["onom_dm"].replace("/", ".")
            parts = s.split(".")
            if len(parts) >= 2:
                try:
                    dd = int(parts[0]); mm = int(parts[1])
                    if mm == luna:
                        namedays.setdefault(dd, []).append(i)
                except Exception:
                    pass

    # DOCX setup
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Mm(210)
    sec.page_height = Mm(297)
    sec.left_margin = Cm(1.5)
    sec.right_margin = Cm(1.5)
    sec.top_margin = Cm(1.6)
    sec.bottom_margin = Cm(1.4)

    # Footer (opțional): dacă există CTX_FOOTER în BIBLIOTECA_TEXTE
    rng_footer = random.Random(hash((an, luna, "CTX_FOOTER")) & 0xffffffff)
    footer_text = pick_ctx_text(lib, rng_footer, "CTX_FOOTER", interval_cod="ALL", sezon="ALL")
    if footer_text:
        # dacă utilizatorul pune {PAGE}, inserăm numărul de pagină în loc
        ft = footer_text
        # Curățăm footer existent
        try:
            for p in list(sec.footer.paragraphs):
                p._p.getparent().remove(p._p)
        except Exception:
            pass
        pft = sec.footer.add_paragraph()
        pft.alignment = WD_ALIGN_PARAGRAPH.CENTER
        # Split pe {PAGE}
        if "{PAGE}" in ft:
            left, right = ft.split("{PAGE}", 1)
            if left:
                pft.add_run(left)
            add_page_field(pft)
            if right:
                pft.add_run(right)
        else:
            pft.add_run(ft)


    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(10)
    style.paragraph_format.space_before = Pt(0)
    style.paragraph_format.space_after = Pt(0)
    style.paragraph_format.line_spacing = 1.05

    days_in_month = calendar.monthrange(an, luna)[1]
    luni_ro = ["", "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"]

    for bi, b in enumerate(benef):
        if bi > 0:
            add_odd_page_section(doc)

        p = doc.add_paragraph("FIȘA BENEFICIARULUI")
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.runs[0].bold = True
        p.runs[0].font.size = Pt(12)

        p2 = doc.add_paragraph("MONITORIZARE ACTIVITĂȚI ZILNICE (dezvoltarea deprinderilor de viață independentă)")
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p2.runs[0].bold = True
        p2.runs[0].font.size = Pt(11)

        doc.add_paragraph("")

        def info(lbl, val):
            pp = doc.add_paragraph()
            pp.add_run(lbl).bold = True
            pp.add_run(val)

        info("Nume beneficiar: ", b["nume_complet"])
        info("Data nașterii: ", "" if not b["birth"] else b["birth"].strftime("%d.%m.%Y"))
        info("Diagnostic și grad de handicap: ", (b["diag"] + ("" if not b.get("grad") else " | " + b["grad"])).strip(" |"))
        info("Perioada: ", f"{luni_ro[luna]} {an}")
        doc.add_paragraph("")

        table = doc.add_table(rows=1, cols=4)
        table.autofit = False
        widths = [Cm(3.0), Cm(8.8), Cm(3.0), Cm(3.2)]
        hdr = table.rows[0].cells
        hdr[0].text = "Data și\ninterval orar"
        hdr[1].text = "Intervenție / Descrierea activității zilnice"
        hdr[2].text = "Nume / prenume / funcție / semnătură"
        hdr[3].text = "Observații"
        for i, c in enumerate(hdr):
            c.width = widths[i]
            set_cell_margins(c, top=110, bottom=110)
            for par in c.paragraphs:
                par.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in par.runs:
                    run.bold = True
        set_table_outer_and_vertical_borders(table, sz="10")
        for c in hdr:
            set_cell_bottom_border(c, val="single", sz="10")

        rng = random.Random(hash((b["nume_complet"], luna, an)) & 0xffffffff)
        e = eval_map.get(b.get("id","").strip())

        for day in range(1, days_in_month + 1):
            date_obj = datetime.date(an, luna, day)
            sezon = season_for_month(luna)

            # resetare marcaje pe zi (pentru a reduce repetiția)
            injected_hranire = False
            injected_igiena = False
            injected_mobcom = False

            # (0) STATUT_BENEFICIAR override (prioritate)
            rec = get_status_for_day(status_map, b.get("id"), date_obj)
            if rec is not None:
                row = table.add_row().cells
                for i, c in enumerate(row):
                    c.width = widths[i]
                    set_cell_margins(c, top=110, bottom=110)
                row[0].text = f"{day:02d}.{luna:02d}.{an}"
                row[1].text = status_text(rec.get("tip",""), rec.get("obs",""))
                row[2].text = ""
                row[3].text = ""
                for c in row:
                    set_cell_bottom_border(c, val="single", sz="10")
                if status_priority(rec.get("tip","")) >= 100:
                    break
                continue

            # (0.5) status_functional INACTIV (soft override)
            if e and _is_inactiv(e.get("status_functional")):
                row = table.add_row().cells
                for i, c in enumerate(row):
                    c.width = widths[i]
                    set_cell_margins(c, top=110, bottom=110)
                row[0].text = f"{day:02d}.{luna:02d}.{an}"
                row[1].text = "Beneficiarul este inactiv (funcțional) în această perioadă."
                row[2].text = ""
                row[3].text = ""
                for c in row:
                    set_cell_bottom_border(c, val="single", sz="10")
                continue

            # (1) eveniment doar dacă e zi reală
            event_type = None
            celebrants = []
            if day in bdays:
                event_type = "birthday"
                celebrants = bdays[day]
            elif day in namedays:
                event_type = "nameday"
                celebrants = namedays[day]

            first_row = True
            day_rows = []

            for i_iv, iv in enumerate(program):
                cod = iv["cod"]
                start = iv["start"]
                label = iv["label"]
                allow_celebration = bool(event_type and (event_slot_id is None or iv["interval_id"] == event_slot_id))
                is_last = (i_iv == len(program) - 1)

                # (A) text de rutină (mai aerisit)
                base_txt = ""
                if cod == "masa":
                    ml = meal_label(start)
                    base_txt = rng.choice([
                        f"Beneficiarul a participat la servirea {ml}",
                        f"Servirea {ml} s-a desfășurat cu sprijinul personalului, după caz",
                        f"Beneficiarul a fost asistat/încurajat la servirea {ml}, conform recomandărilor",
                    ])
                elif cod == "dimineata":
                    base_txt = rng.choice([
                        "Activități de autoîngrijire și igienă personală matinală",
                        "Rutina de dimineață (autoîngrijire și igienă personală)",
                    ])
                else:
                    base_txt = pick_activity_text(cod, sezon, activitati_by_cod, lib, rng, allow_celebration=allow_celebration) or \
                               rng.choice(["Beneficiarul a participat la activități de grup", "Beneficiarul a fost implicat în activități recreative și educative"])

                # (B) injectare eveniment (doar în slotul de eveniment)
                if allow_celebration and iv["interval_id"] == event_slot_id:
                    if event_type == "birthday":
                        if bi in celebrants:
                            age = calc_age(b["birth"], an, luna, day)
                            extra = rng.choice(EVENT_TEXTS["bday_celebrant"]).format(age=age)
                        else:
                            extra = rng.choice(EVENT_TEXTS["bday_others"])
                    else:
                        if bi in celebrants:
                            extra = rng.choice(EVENT_TEXTS["nameday_target"])
                        else:
                            extra = rng.choice(EVENT_TEXTS["nameday_others"])
                    base_txt = f"{base_txt}. {extra}"

                # (C) CORE 2: injectări funcționale rare
                inj = ""
                if e:
                    # Igienă: zilnic sau periodic (1/2 zile)
                    if cod == "dimineata" and (INJECT_IGIENA_EVERY_N_DAYS <= 1 or (day % INJECT_IGIENA_EVERY_N_DAYS == 0)) and (not injected_igiena):
                        inj = pick_or_fallback(lib, rng, "IGH", e.get("igiena_personala"), text_igiena(e, rng), sezon)
                        injected_igiena = True

                    # Hrănire: la toate mesele sau o singură dată pe zi (preferat)
                    elif cod == "masa":
                        ml = meal_label(start)
                        want = True
                        if INJECT_HRANIRE_ONCE_PER_DAY:
                            if injected_hranire:
                                want = False
                            else:
                                pref = (INJECT_HRANIRE_PREFER or "pranz").lower()
                                if pref == "mic_dejun" and ml != "micului dejun":
                                    want = False
                                elif pref == "pranz" and ml != "prânzului":
                                    want = False
                                elif pref == "cina" and ml != "cinei":
                                    want = False
                        if want:
                            inj = pick_or_fallback(lib, rng, "HRA", e.get("hranire"), text_hranire(e, rng), sezon)
                            injected_hranire = True

                    # Mobilitate + comunicare: doar în slotul târziu și periodic
                    elif cod == "dupa_amiaza" and iv["interval_id"] == event_slot_id:
                        if (INJECT_MOB_COM_EVERY_N_DAYS <= 1 or (day % INJECT_MOB_COM_EVERY_N_DAYS == 0)) and (not injected_mobcom):
                            inj = join_sentences(
                                pick_or_fallback(lib, rng, "MOB", e.get("mobilitate"), text_mobilitate(e, rng), sezon),
                                pick_or_fallback(lib, rng, "COM", e.get("comunicare_verbala"), text_comunicare(e, rng), sezon)
                            )
                            injected_mobcom = True

                # Texte de context (rare): înainte de masă / la final de zi
                ctx_pre = ""
                ctx_post = ""
                if cod == "masa":
                    # rar + doar la prânz/cină de regulă (micul dejun mai rar)
                    ml = meal_label(start)
                    if rng.random() < CTX_MASA_PROB and (ml != "micului dejun" or rng.random() < 0.35):
                        ctx_pre = pick_ctx_text(lib, rng, "CTX_MASA", "masa", sezon)
                if is_last and rng.random() < CTX_ZI_PROB:
                    ctx_post = pick_ctx_text(lib, rng, "CTX_ZI", "ALL", sezon)

                full_txt = base_txt.strip()
                if ctx_pre:
                    full_txt = f"{ctx_pre}. {full_txt}".strip()
                if inj:
                    full_txt = f"{full_txt}. {inj}".strip()
                if ctx_post:
                    full_txt = f"{full_txt}. {ctx_post}".strip()

                # row write
                row = table.add_row().cells
                for i, c in enumerate(row):
                    c.width = widths[i]
                    set_cell_margins(c, top=110, bottom=110)

                row[0].text = f"{day:02d}.{luna:02d}.{an}\n{label}" if first_row else label
                row[1].text = full_txt
                row[2].text = ""
                row[3].text = iv["obs"]

                first_row = False
                day_rows.append(row)

            for c in day_rows[-1]:
                set_cell_bottom_border(c, val="single", sz="10")

    # ── Folder output organizat ──
    from pathlib import Path as _Path
    _luni_ro = ["","Ianuarie","Februarie","Martie","Aprilie","Mai","Iunie",
               "Iulie","August","Septembrie","Octombrie","Noiembrie","Decembrie"]
    _script_dir = _Path(__file__).resolve().parent
    _luna_str   = _luni_ro[luna].lower()
    _out_dir    = _script_dir / "output" / f"{an}_{luna:02d}_{_luni_ro[luna]}"
    _out_dir.mkdir(parents=True, exist_ok=True)
    _output_path = _out_dir / f"Fise_Sprijin_Continuu_{_luna_str}_{an}.docx"
    doc.save(str(_output_path))
    print("Gata! Generat:", _output_path)
    print("Notă: dacă nu vezi micul dejun, verifică PROGRAM_ZILNIC (ora_start/ora_stop și ordine).")

if __name__ == "__main__":
    main()