"""
Generator Condică de Prescripții Medicamente și Materiale Sanitare
CIAPAD Casa Olandeză — document lunar centralizat per centru
Totalizator per medicament (suma tuturor beneficiarilor)
"""

from docx import Document
from docx.shared import Cm, Pt, Mm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from openpyxl import load_workbook
import calendar, datetime
from pathlib import Path

EXCEL   = "Master_CORE_v2_CORECTAT.xlsx"
LUNI_RO = ["","Ianuarie","Februarie","Martie","Aprilie","Mai","Iunie",
           "Iulie","August","Septembrie","Octombrie","Noiembrie","Decembrie"]
JUDET      = "Giurgiu"
LOCALITATE = "Carpeniș"
UNITATE    = "CIAPAD"
SECTIE     = "Casa Olandeză"

def norm_key(s):
    import unicodedata, re
    s = str(s).strip().lower()
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r'\s+', ' ', s)

def get_headers(ws):
    h = {}
    row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
    for idx, v in enumerate(row):
        if v is not None:
            h[norm_key(v)] = idx
    return h

def find_col(h, *needles):
    for n in needles:
        nk = norm_key(n)
        if nk in h: return h[nk]
    for k, idx in h.items():
        for n in needles:
            if norm_key(n) in k: return idx
    return None

def get_sheet(wb, *names):
    lower = {s.lower(): s for s in wb.sheetnames}
    for n in names:
        if n.lower() in lower: return wb[lower[n.lower()]]
    return None

def resolve_excel(name):
    sd = Path(__file__).resolve().parent
    p  = sd / name
    if p.exists(): return p
    cands = sorted(sd.glob("*.xlsx"))
    if cands:
        print(f"Notă: nu găsesc '{name}'. Folosesc: {cands[0].name}")
        return cands[0]
    return sd / input("Introdu numele fișierului Excel: ").strip()

def fmt_cant(v):
    if v == int(v): return str(int(v))
    return str(round(v, 1)).replace(".", ",")

def norm_forma(forma):
    f = forma.lower().strip()
    if f in ("solutie","sol","soluție","soluţie"): return "Soluție"
    if f in ("sirop",): return "Sirop"
    if f in ("compr","comprimate","tb","tbl"): return ""
    return forma.strip()

def load_totalizator(wb, zile_luna):
    ws = get_sheet(wb, "MEDICATIE")
    if ws is None: raise RuntimeError("Nu găsesc foaia MEDICATIE.")
    h = get_headers(ws)
    agregate = {}

    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or all(v is None or str(v).strip() == "" for v in row):
            continue
        activ = str(row[find_col(h, "activ")] or "DA").strip().upper()
        if activ != "DA": continue

        med   = str(row[find_col(h, "medicament")] or "").strip()
        forma = norm_forma(str(row[find_col(h, "forma","concentratie","forma/concentratie")] or ""))
        um    = str(row[find_col(h, "unitate_masura","unitate masura")] or "compr").strip()
        dim   = float(row[find_col(h, "dimineata","dimineată")] or 0)
        pranz = float(row[find_col(h, "pranz","prânz")] or 0)
        seara = float(row[find_col(h, "seara")] or 0)
        adm   = str(row[find_col(h, "administrare")] or "").strip()

        if not med: continue
        cant_zi = dim + pranz + seara
        if cant_zi == 0 and not adm: continue  # excludem dozele 0 fără obs speciale

        cheie = (med.lower(), forma.lower(), um.lower())
        prescriptie = med + (f" {forma}" if forma else "")

        cant_luna = cant_zi * zile_luna
        if cheie not in agregate:
            agregate[cheie] = {"prescriptie": prescriptie, "um": um,
                               "cantitate": 0.0, "obs": adm}
        agregate[cheie]["cantitate"] += cant_luna
        if adm and not agregate[cheie]["obs"]:
            agregate[cheie]["obs"] = adm

    return sorted(agregate.values(), key=lambda x: x["prescriptie"].lower())

# ── DOCX helpers ──
def set_borders(cell, sz="6", color="000000"):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcB = tcPr.find(qn("w:tcBorders"))
    if tcB is None:
        tcB = OxmlElement("w:tcBorders"); tcPr.append(tcB)
    for edge in ("top","bottom","left","right"):
        el = tcB.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}"); tcB.append(el)
        el.set(qn("w:val"), "single"); el.set(qn("w:sz"), sz)
        el.set(qn("w:color"), color); el.set(qn("w:space"), "0")

def set_shading(cell, fill):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = tcPr.find(qn("w:shd"))
    if shd is None: shd = OxmlElement("w:shd"); tcPr.append(shd)
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)

def set_margins(cell, top=60, start=80, bottom=60, end=80):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.find(qn("w:tcMar"))
    if tcMar is None: tcMar = OxmlElement("w:tcMar"); tcPr.append(tcMar)
    for m, v in [("top",top),("start",start),("bottom",bottom),("end",end)]:
        node = tcMar.find(qn(f"w:{m}"))
        if node is None: node = OxmlElement(f"w:{m}"); tcMar.append(node)
        node.set(qn("w:w"), str(v)); node.set(qn("w:type"), "dxa")

def set_row_h(row, h_cm):
    tr = row._tr
    trPr = tr.find(qn("w:trPr"))
    if trPr is None: trPr = OxmlElement("w:trPr"); tr.insert(0, trPr)
    trH = trPr.find(qn("w:trHeight"))
    if trH is None: trH = OxmlElement("w:trHeight"); trPr.append(trH)
    trH.set(qn("w:val"), str(int(h_cm * 567))); trH.set(qn("w:hRule"), "atLeast")

def wc(cell, text, bold=False, size=9, align=WD_ALIGN_PARAGRAPH.LEFT, white=False):
    for p in cell.paragraphs: p.clear()
    p = cell.paragraphs[0]
    p.alignment = align
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after  = Pt(0)
    run = p.add_run(text)
    run.bold = bold; run.font.size = Pt(size); run.font.name = "Times New Roman"
    if white: run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

def adauga_subsol_legal(doc, baza_legala=None):
    """Adaugă baza legală în subsolul documentului — corp 6.5pt, centrat."""
    from docx.shared import Pt, RGBColor
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    if baza_legala is None:
        baza_legala = (
            "Document generat de CORE v3.0 — o inițiativă SocialHub©  |  "
            "Temei legal: Ord. 82/2019 actualizat prin Ord. 3222/2024 (MMSS)  |  "
            "Legea 292/2011  |  Legea 448/2006  |  "
            "Document editabil — utilizatorul își asumă responsabilitatea "
            "pentru veridicitatea înscrisurilor după semnare și arhivare."
        )
    for section in doc.sections:
        footer = section.footer
        if footer.paragraphs:
            p = footer.paragraphs[0]
            p.clear()
        else:
            p = footer.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after  = Pt(0)
        pPr = p._p.get_or_add_pPr()
        pBdr = OxmlElement("w:pBdr")
        top = OxmlElement("w:top")
        top.set(qn("w:val"), "single"); top.set(qn("w:sz"), "4")
        top.set(qn("w:space"), "1");    top.set(qn("w:color"), "CCCCCC")
        pBdr.append(top); pPr.append(pBdr)
        run = p.add_run(baza_legala)
        run.font.size = Pt(6.5)
        run.font.name = "Times New Roman"
        run.font.color.rgb = RGBColor(0x6B, 0x72, 0x80)


def main():
    luna = int(input("Luna (1-12): ").strip())
    an   = int(input("Anul (ex: 2026): ").strip())

    zile_luna = calendar.monthrange(an, luna)[1]
    luna_str  = LUNI_RO[luna]
    prima_zi  = f"01.{luna:02d}.{an}"
    ultima_zi = f"{zile_luna:02d}.{luna:02d}.{an}"

    wb           = load_workbook(resolve_excel(EXCEL), data_only=True)
    medicamente  = load_totalizator(wb, zile_luna)
    print(f"Medicamente distincte: {len(medicamente)}")

    sd      = Path(__file__).resolve().parent
    out_dir = sd / "output" / f"{an}_{luna:02d}_{luna_str}"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"Condica_Medicamente_{luna_str.lower()}_{an}.docx"

    # ── Document landscape ──
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = Mm(297); sec.page_height = Mm(210)
    sec.left_margin = sec.right_margin = Cm(1.8)
    sec.top_margin  = sec.bottom_margin = Cm(1.5)
    sectPr = sec._sectPr
    pgSz = sectPr.find(qn("w:pgSz"))
    if pgSz is None: pgSz = OxmlElement("w:pgSz"); sectPr.append(pgSz)
    pgSz.set(qn("w:orient"), "landscape")

    sty = doc.styles["Normal"]
    sty.font.name = "Times New Roman"; sty.font.size = Pt(9)
    sty.paragraph_format.space_before = sty.paragraph_format.space_after = Pt(1)

    # ── Antet ──
    tbl_top = doc.add_table(rows=1, cols=2)
    tbl_top.autofit = False
    cl = tbl_top.rows[0].cells[0]; cl.width = Cm(15)
    cr = tbl_top.rows[0].cells[1]; cr.width = Cm(11)

    for txt in [f"Județul {JUDET}", f"Localitatea {LOCALITATE}",
                f"Unitatea sanitară {UNITATE}", f"Secția {SECTIE}"]:
        p = cl.add_paragraph()
        p.paragraph_format.space_before = p.paragraph_format.space_after = Pt(1)
        r = p.add_run(txt); r.font.size = Pt(9); r.font.name = "Times New Roman"

    p_dr = cr.paragraphs[0]
    p_dr.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_dr.paragraph_format.space_after = Pt(2)
    r = p_dr.add_run(f"Anul {an}   luna {luna_str.upper()}   ziua {zile_luna}")
    r.bold = True; r.font.size = Pt(10); r.font.name = "Times New Roman"

    p_tot = cr.add_paragraph()
    p_tot.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p_tot.add_run(f"TOTAL CH.   {prima_zi} – {ultima_zi}")
    r.bold = True; r.font.size = Pt(9); r.font.name = "Times New Roman"

    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(4)

    p_tit = doc.add_paragraph()
    p_tit.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_tit.paragraph_format.space_before = Pt(2); p_tit.paragraph_format.space_after = Pt(8)
    r = p_tit.add_run("CONDICĂ DE PRESCRIPȚII MEDICAMENTE ȘI MATERIALE SANITARE")
    r.bold = True; r.font.size = Pt(13); r.font.name = "Times New Roman"

    # ── Tabel ──
    # Nr | Prescripția | UM | Cant.Cerută | Cant.Eliberată | Preț unitar | Valoare totală | Observații
    CW = [Cm(1.2), Cm(10.0), Cm(1.8), Cm(2.5), Cm(2.5), Cm(2.2), Cm(2.8), Cm(3.2)]
    HT = ["Nr.\ncrt.", "PRESCRIPȚIA", "U.M.", "Cantitatea\nCerută",
          "Cantitatea\nEliberată", "Preț\nunitar", "Valoare\ntotală", "Observații"]
    NR = ["1","2","3","4","5","6","7","8"]

    tbl = doc.add_table(rows=1, cols=8)
    tbl.autofit = False; tbl.style = "Table Grid"

    # Header verde
    hr = tbl.rows[0]; set_row_h(hr, 1.2)
    for ci, (t, w) in enumerate(zip(HT, CW)):
        c = hr.cells[ci]; c.width = w
        wc(c, t, bold=True, size=8, align=WD_ALIGN_PARAGRAPH.CENTER, white=True)
        set_shading(c, "1A6B3C"); set_borders(c); set_margins(c, 40, 40, 40, 40)

    # Numerotare coloane
    nr_r = tbl.add_row(); set_row_h(nr_r, 0.5)
    for ci, (n, w) in enumerate(zip(NR, CW)):
        c = nr_r.cells[ci]; c.width = w
        wc(c, n, size=8, align=WD_ALIGN_PARAGRAPH.CENTER)
        set_shading(c, "E8F5EE"); set_borders(c); set_margins(c, 20, 40, 20, 40)

    # Date
    for idx, med in enumerate(medicamente):
        row = tbl.add_row(); set_row_h(row, 0.72)
        fill = "FFFFFF" if idx % 2 == 0 else "F5F9F7"
        vals = [
            (str(idx+1),              WD_ALIGN_PARAGRAPH.CENTER, False),
            (med["prescriptie"],      WD_ALIGN_PARAGRAPH.LEFT,   True),
            (med["um"],               WD_ALIGN_PARAGRAPH.CENTER, False),
            (fmt_cant(med["cantitate"]), WD_ALIGN_PARAGRAPH.CENTER, False),
            ("",                      WD_ALIGN_PARAGRAPH.CENTER, False),
            ("",                      WD_ALIGN_PARAGRAPH.CENTER, False),
            ("",                      WD_ALIGN_PARAGRAPH.CENTER, False),
            (med["obs"] or "",        WD_ALIGN_PARAGRAPH.LEFT,   False),
        ]
        for ci, (t, al, bd) in enumerate(vals):
            c = row.cells[ci]; c.width = CW[ci]
            wc(c, t, bold=bd, size=9, align=al)
            set_shading(c, fill); set_borders(c); set_margins(c, 30, 40, 30, 40)

    # Total
    tr = tbl.add_row(); set_row_h(tr, 0.8)
    for ci, w in enumerate(CW):
        c = tr.cells[ci]; c.width = w
        wc(c, "Total\nlei" if ci == 5 else "", bold=(ci==5), size=8,
           align=WD_ALIGN_PARAGRAPH.CENTER)
        set_shading(c, "E8F5EE"); set_borders(c); set_margins(c, 30, 40, 30, 40)

    # ── Semnături ──
    doc.add_paragraph().paragraph_format.space_after = Pt(8)
    tbl_s = doc.add_table(rows=1, cols=4)
    tbl_s.autofit = False
    for ci, txt in enumerate([
        "Semnătura și parafa medicului\n\n\n................................",
        "Ștampila\n\n\n................................",
        "Am eliberat,\n\n\n................................",
        "Am primit,\n\n\n................................",
    ]):
        c = tbl_s.rows[0].cells[ci]; c.width = Cm(6.5)
        p = c.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = p.paragraph_format.space_after = Pt(0)
        r = p.add_run(txt); r.font.size = Pt(9); r.font.name = "Times New Roman"
        set_margins(c, 60, 60, 60, 60)

    adauga_subsol_legal(doc)
    doc.save(str(out_path))
    print(f"\nGata! Generat: {out_path}")
    print(f"Medicamente distincte: {len(medicamente)} | {luna_str} {an} ({zile_luna} zile)")

if __name__ == "__main__":
    main()
