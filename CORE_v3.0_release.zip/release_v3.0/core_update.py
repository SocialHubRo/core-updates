"""
CORE — Modul Actualizare Online și Control Activare
o inițiativă SocialHub©

Verifică la pornire:
- Dacă aplicația e activă (licență validă)
- Dacă există o versiune nouă disponibilă
- Data de expirare a licenței curente

Sursa: GitHub (migrabil ulterior pe socialhub.ro)
"""

import json
import datetime
import threading
from pathlib import Path

# ── Configurare URL ──
# Când migrăm pe socialhub.ro, schimbăm doar această linie
STATUS_URL = "https://raw.githubusercontent.com/SocialHubRo/core-updates/main/status.json"

CONFIG_FILE = Path(__file__).resolve().parent / ".core_config.json"
APP_VERSION = "3.0"

# ── Rezultat verificare (completat asincron) ──
_rezultat_verificare = {
    "verificat":     False,
    "online":        False,
    "status":        "activ",
    "versiune_noua": None,
    "mesaj":         "",
    "expira":        None,
}

def _citeste_config():
    """Citește configurația locală."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _salveaza_config(data):
    """Salvează configurația locală."""
    try:
        existing = _citeste_config()
        existing.update(data)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _verifica_online(callback=None):
    """Verifică serverul de actualizări în fundal."""
    global _rezultat_verificare
    try:
        import urllib.request
        import ssl

        # Timeout 5 secunde — nu blochează pornirea
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(
            STATUS_URL,
            headers={"User-Agent": f"CORE/{APP_VERSION}"}
        )
        with urllib.request.urlopen(req, timeout=5, context=ctx) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        _rezultat_verificare["online"]    = True
        _rezultat_verificare["status"]    = data.get("status", "activ")
        _rezultat_verificare["mesaj"]     = data.get("mesaj", "")
        _rezultat_verificare["expira"]    = data.get("data_expirare")
        _rezultat_verificare["verificat"] = True

        # Verifică versiune nouă
        versiune_server = data.get("versiune_curenta", APP_VERSION)
        if _versiune_mai_noua(versiune_server, APP_VERSION):
            _rezultat_verificare["versiune_noua"] = versiune_server

        # Salvează ultima verificare reușită
        _salveaza_config({
            "ultima_verificare": datetime.datetime.now().isoformat(),
            "status_server":     _rezultat_verificare["status"],
        })

    except Exception:
        # Fără internet sau server indisponibil — continuăm normal
        _rezultat_verificare["online"]    = False
        _rezultat_verificare["verificat"] = True

        # Verificăm dacă a trecut prea mult timp fără verificare
        config = _citeste_config()
        ultima = config.get("ultima_verificare")
        if ultima:
            try:
                dt_ultima = datetime.datetime.fromisoformat(ultima)
                zile_fara_verificare = (datetime.datetime.now() - dt_ultima).days
                if zile_fara_verificare > 90:
                    _rezultat_verificare["status"] = "avertisment_offline"
                    _rezultat_verificare["mesaj"]  = (
                        f"Nu s-a putut verifica licența de {zile_fara_verificare} zile. "
                        f"Verificați conexiunea la internet."
                    )
            except Exception:
                pass

    if callback:
        callback(_rezultat_verificare)

def _versiune_mai_noua(v_server, v_local):
    """Compară versiuni de forma '3.0', '3.1', '4.0'."""
    try:
        sv = [int(x) for x in str(v_server).split(".")]
        lv = [int(x) for x in str(v_local).split(".")]
        return sv > lv
    except Exception:
        return False

def porneste_verificare(callback=None):
    """Lansează verificarea în fundal — non-blocant."""
    t = threading.Thread(
        target=_verifica_online,
        args=(callback,),
        daemon=True
    )
    t.start()

def get_rezultat():
    """Returnează rezultatul ultimei verificări."""
    return _rezultat_verificare.copy()

def este_blocat():
    """
    Returnează True dacă aplicația trebuie blocată.
    Blochează doar dacă serverul a confirmat explicit dezactivarea.
    Fără internet = nu blochează.
    """
    r = _rezultat_verificare
    if not r["online"]:
        return False  # Offline = nu blochează
    return r["status"] in ("dezactivat", "expirat", "inlocuit")

def get_mesaj_blocare():
    """Returnează mesajul de afișat când e blocat."""
    r = _rezultat_verificare
    if r["status"] == "dezactivat":
        return r["mesaj"] or (
            "Această instalare CORE a fost dezactivată.\n"
            "Contactați administratorul pentru detalii."
        )
    if r["status"] == "expirat":
        return (
            f"Licența CORE a expirat.\n"
            f"Contactați administratorul pentru reînnoire."
        )
    if r["status"] == "inlocuit":
        return (
            "CORE a fost înlocuit de platforma web SocialHub.\n"
            "Contactați administratorul pentru acces la noua platformă."
        )
    return r["mesaj"] or "Aplicația nu este disponibilă momentan."
